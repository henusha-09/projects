#pragma once

namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for Transport
	/// </summary>
	public ref class Transport : public System::Windows::Forms::Form
	{
	public:
		Transport(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Transport()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^ Uber;
	protected:

	protected:



	private: System::Windows::Forms::CheckBox^ Taxi;

	private: System::Windows::Forms::CheckBox^ LuxuryCar;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker1;
	private: System::Windows::Forms::CheckBox^ ChauffeurDriven;



	private: System::Windows::Forms::BindingSource^ bindingSource1;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ ClientID;
	private: System::Windows::Forms::Button^ BookBtn;
	private: System::Windows::Forms::Button^ SearchBtn;
	private: System::Windows::Forms::TextBox^ TransportID;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker2;
	private: System::Windows::Forms::Button^ Delete;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Transport::typeid));
			this->Uber = (gcnew System::Windows::Forms::CheckBox());
			this->Taxi = (gcnew System::Windows::Forms::CheckBox());
			this->LuxuryCar = (gcnew System::Windows::Forms::CheckBox());
			this->dateTimePicker1 = (gcnew System::Windows::Forms::DateTimePicker());
			this->ChauffeurDriven = (gcnew System::Windows::Forms::CheckBox());
			this->bindingSource1 = (gcnew System::Windows::Forms::BindingSource(this->components));
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->ClientID = (gcnew System::Windows::Forms::TextBox());
			this->BookBtn = (gcnew System::Windows::Forms::Button());
			this->SearchBtn = (gcnew System::Windows::Forms::Button());
			this->TransportID = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->dateTimePicker2 = (gcnew System::Windows::Forms::DateTimePicker());
			this->Delete = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->bindingSource1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// Uber
			// 
			this->Uber->AutoSize = true;
			this->Uber->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Uber->Location = System::Drawing::Point(57, 168);
			this->Uber->Name = L"Uber";
			this->Uber->Size = System::Drawing::Size(68, 24);
			this->Uber->TabIndex = 3;
			this->Uber->Text = L"Uber";
			this->Uber->UseVisualStyleBackColor = true;
			// 
			// Taxi
			// 
			this->Taxi->AutoSize = true;
			this->Taxi->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Taxi->Location = System::Drawing::Point(57, 122);
			this->Taxi->Name = L"Taxi";
			this->Taxi->Size = System::Drawing::Size(61, 24);
			this->Taxi->TabIndex = 4;
			this->Taxi->Text = L"Taxi";
			this->Taxi->UseVisualStyleBackColor = true;
			// 
			// LuxuryCar
			// 
			this->LuxuryCar->AutoSize = true;
			this->LuxuryCar->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->LuxuryCar->Location = System::Drawing::Point(57, 73);
			this->LuxuryCar->Name = L"LuxuryCar";
			this->LuxuryCar->Size = System::Drawing::Size(106, 24);
			this->LuxuryCar->TabIndex = 3;
			this->LuxuryCar->Text = L"Luxury car";
			this->LuxuryCar->UseVisualStyleBackColor = true;
			// 
			// dateTimePicker1
			// 
			this->dateTimePicker1->Location = System::Drawing::Point(57, 256);
			this->dateTimePicker1->Name = L"dateTimePicker1";
			this->dateTimePicker1->Size = System::Drawing::Size(256, 22);
			this->dateTimePicker1->TabIndex = 5;
			// 
			// ChauffeurDriven
			// 
			this->ChauffeurDriven->AutoSize = true;
			this->ChauffeurDriven->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ChauffeurDriven->Location = System::Drawing::Point(219, 73);
			this->ChauffeurDriven->Name = L"ChauffeurDriven";
			this->ChauffeurDriven->Size = System::Drawing::Size(158, 24);
			this->ChauffeurDriven->TabIndex = 3;
			this->ChauffeurDriven->Text = L"Chauffeur Driven";
			this->ChauffeurDriven->UseVisualStyleBackColor = true;
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(51, 463);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersWidth = 51;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(441, 279);
			this->dataGridView1->TabIndex = 8;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(173, 388);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(66, 16);
			this->label2->TabIndex = 10;
			this->label2->Text = L"Client ID";
			// 
			// ClientID
			// 
			this->ClientID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ClientID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ClientID->Location = System::Drawing::Point(170, 408);
			this->ClientID->Name = L"ClientID";
			this->ClientID->Size = System::Drawing::Size(99, 20);
			this->ClientID->TabIndex = 9;
			// 
			// BookBtn
			// 
			this->BookBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->BookBtn->Location = System::Drawing::Point(323, 408);
			this->BookBtn->Name = L"BookBtn";
			this->BookBtn->Size = System::Drawing::Size(75, 28);
			this->BookBtn->TabIndex = 11;
			this->BookBtn->Text = L"Book";
			this->BookBtn->UseVisualStyleBackColor = true;
			this->BookBtn->Click += gcnew System::EventHandler(this, &Transport::BookBtn_Click);
			// 
			// SearchBtn
			// 
			this->SearchBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->SearchBtn->Location = System::Drawing::Point(417, 764);
			this->SearchBtn->Name = L"SearchBtn";
			this->SearchBtn->Size = System::Drawing::Size(75, 28);
			this->SearchBtn->TabIndex = 12;
			this->SearchBtn->Text = L"Search";
			this->SearchBtn->UseVisualStyleBackColor = true;
			this->SearchBtn->Click += gcnew System::EventHandler(this, &Transport::SearchBtn_Click);
			// 
			// TransportID
			// 
			this->TransportID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->TransportID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->TransportID->Location = System::Drawing::Point(51, 408);
			this->TransportID->Name = L"TransportID";
			this->TransportID->Size = System::Drawing::Size(99, 20);
			this->TransportID->TabIndex = 9;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(54, 388);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(93, 16);
			this->label1->TabIndex = 10;
			this->label1->Text = L"Transport ID";
			// 
			// dateTimePicker2
			// 
			this->dateTimePicker2->Location = System::Drawing::Point(57, 329);
			this->dateTimePicker2->Name = L"dateTimePicker2";
			this->dateTimePicker2->Size = System::Drawing::Size(256, 22);
			this->dateTimePicker2->TabIndex = 5;
			// 
			// Delete
			// 
			this->Delete->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Delete->Location = System::Drawing::Point(417, 408);
			this->Delete->Name = L"Delete";
			this->Delete->Size = System::Drawing::Size(75, 28);
			this->Delete->TabIndex = 13;
			this->Delete->Text = L"Delete";
			this->Delete->UseVisualStyleBackColor = true;
			this->Delete->Click += gcnew System::EventHandler(this, &Transport::Delete_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(23, 32);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(144, 22);
			this->label3->TabIndex = 10;
			this->label3->Text = L"Transport type";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(48, 227);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(77, 16);
			this->label4->TabIndex = 10;
			this->label4->Text = L"Date from";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(48, 304);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(57, 16);
			this->label5->TabIndex = 10;
			this->label5->Text = L"Date to";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->pictureBox1->Location = System::Drawing::Point(573, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(507, 807);
			this->pictureBox1->TabIndex = 14;
			this->pictureBox1->TabStop = false;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel1->Location = System::Drawing::Point(51, 432);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(99, 3);
			this->panel1->TabIndex = 15;
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel2->Location = System::Drawing::Point(170, 433);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(99, 3);
			this->panel2->TabIndex = 15;
			// 
			// Transport
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1080, 807);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->Delete);
			this->Controls->Add(this->BookBtn);
			this->Controls->Add(this->SearchBtn);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->TransportID);
			this->Controls->Add(this->ClientID);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->dateTimePicker2);
			this->Controls->Add(this->dateTimePicker1);
			this->Controls->Add(this->ChauffeurDriven);
			this->Controls->Add(this->LuxuryCar);
			this->Controls->Add(this->Uber);
			this->Controls->Add(this->Taxi);
			this->Name = L"Transport";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Transport";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->bindingSource1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		private: System::Void SearchBtn_Click(System::Object^ sender, System::EventArgs^ e) {

			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			DateTime datePicker1 = dateTimePicker1->Value;
			int year1 = datePicker1.Year;
			int month1 = datePicker1.Month;
			int day1 = datePicker1.Day;
			String^ from = "  " + year1 + "-" + month1 + "-" + day1 + "  ";

			DateTime datePicker2 = dateTimePicker2->Value;
			int year2 = datePicker2.Year;
			int month2 = datePicker2.Month;
			int day2 = datePicker2.Day;
			String^ to = "  " + year2 + "-" + month2 + "-" + day2 + "  ";

			if (LuxuryCar->Checked)
			{
				MySqlDataAdapter^ sda = gcnew MySqlDataAdapter("SELECT * FROM transport_availability JOIN transport_list ON transport_availability.transport_id=transport_list.transport_id WHERE type='Luxury Car' AND status=0 AND date BETWEEN '" + from + "' AND '" + to + "' ", con);

				DataTable^ dt = gcnew DataTable();
				sda->Fill(dt);

				bindingSource1->DataSource = dt;
				dataGridView1->DataSource = bindingSource1;
			}
		}

		private: System::Void BookBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			DateTime datePicker1 = dateTimePicker1->Value;
			int year1 = datePicker1.Year;
			int month1 = datePicker1.Month;
			int day1 = datePicker1.Day;
			String^ from = "  " + year1 + "-" + month1 + "-" + day1 + "  ";

			DateTime datePicker2 = dateTimePicker2->Value;
			int year2 = datePicker2.Year;
			int month2 = datePicker2.Month;
			int day2 = datePicker2.Day;
			String^ to = "  " + year2 + "-" + month2 + "-" + day2 + "  ";

			int clientid = Int32::Parse(ClientID->Text);

			

			if (LuxuryCar->Checked)
			{
				int transportid = Int32::Parse(TransportID->Text);

				MySqlCommand^ cmd = gcnew MySqlCommand("UPDATE transport_availability  SET client_id=" + clientid + ", status=1 WHERE transport_id=" + transportid + " AND date BETWEEN '" + from + "' AND '" + to + "' ", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}

			if (ChauffeurDriven->Checked)
			{
				int transportid = Int32::Parse(TransportID->Text);
	
				MySqlCommand ^ cmd = gcnew MySqlCommand("UPDATE transport_availability  SET chauffeur_driven = 1 WHERE transport_id = " + transportid + " AND date BETWEEN '" + from + "' AND '" + to + "'", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
				
			}

			if (Taxi->Checked)
			{
				MySqlCommand ^ cmd = gcnew MySqlCommand("INSERT INTO transport_other (client_id, type, date_from, date_to) VALUES (" + clientid + ", 'Taxi', '" + from + "', '" + to + "' )", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}

			if (Uber->Checked)
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO transport_other (client_id, type, date_from, date_to) VALUES (" + clientid + ", 'Uber', '" + from + "', '" + to + "' )", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}



			Transport::Close();

		}




		private: System::Void Delete_Click(System::Object^ sender, System::EventArgs^ e) {
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			int clientid = Int32::Parse(ClientID->Text);
			MySqlCommand^ cmd = gcnew MySqlCommand("delete from transport_availability where client_id=" + clientid + " ", con);
			MySqlCommand^ cmd1 = gcnew MySqlCommand("delete from transport_other where client_id=" + clientid + " ", con);

			con->Open();
			MySqlDataReader^ dr = cmd->ExecuteReader();
			con->Close();

			con->Open();
			MySqlDataReader^ dr1 = cmd1->ExecuteReader();
			con->Close();
		}
};
}
