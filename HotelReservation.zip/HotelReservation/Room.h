#pragma once

namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for Room
	/// </summary>
	public ref class Room : public System::Windows::Forms::Form
	{
	public:
		Room(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Room()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^ BedroomChk;
	private: System::Windows::Forms::CheckBox^ ConferenceRoomChk;


	protected:


	private: System::Windows::Forms::DateTimePicker^ dateTimePicker1;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker2;
	private: System::Windows::Forms::Button^ SearchBtn;
	private: System::Windows::Forms::CheckBox^ GardenViewChk;

	private: System::Windows::Forms::CheckBox^ BeachPavilionChk;





	private: System::Windows::Forms::Button^ BookBtn;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::BindingSource^ bindingSource1;
	private: System::Windows::Forms::TextBox^ RoomID;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ ClientID;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ Update;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;


	private: System::ComponentModel::IContainer^ components;
	protected:


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Room::typeid));
			this->BedroomChk = (gcnew System::Windows::Forms::CheckBox());
			this->ConferenceRoomChk = (gcnew System::Windows::Forms::CheckBox());
			this->dateTimePicker1 = (gcnew System::Windows::Forms::DateTimePicker());
			this->dateTimePicker2 = (gcnew System::Windows::Forms::DateTimePicker());
			this->SearchBtn = (gcnew System::Windows::Forms::Button());
			this->GardenViewChk = (gcnew System::Windows::Forms::CheckBox());
			this->BeachPavilionChk = (gcnew System::Windows::Forms::CheckBox());
			this->BookBtn = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->bindingSource1 = (gcnew System::Windows::Forms::BindingSource(this->components));
			this->RoomID = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->ClientID = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->Update = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->bindingSource1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// BedroomChk
			// 
			this->BedroomChk->AutoSize = true;
			this->BedroomChk->BackColor = System::Drawing::Color::Transparent;
			this->BedroomChk->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BedroomChk->Location = System::Drawing::Point(64, 74);
			this->BedroomChk->Name = L"BedroomChk";
			this->BedroomChk->Size = System::Drawing::Size(100, 24);
			this->BedroomChk->TabIndex = 0;
			this->BedroomChk->Text = L"Bedroom";
			this->BedroomChk->UseVisualStyleBackColor = false;
			// 
			// ConferenceRoomChk
			// 
			this->ConferenceRoomChk->AutoSize = true;
			this->ConferenceRoomChk->BackColor = System::Drawing::Color::Transparent;
			this->ConferenceRoomChk->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ConferenceRoomChk->Location = System::Drawing::Point(248, 74);
			this->ConferenceRoomChk->Name = L"ConferenceRoomChk";
			this->ConferenceRoomChk->Size = System::Drawing::Size(162, 24);
			this->ConferenceRoomChk->TabIndex = 0;
			this->ConferenceRoomChk->Text = L"Conference room";
			this->ConferenceRoomChk->UseVisualStyleBackColor = false;
			// 
			// dateTimePicker1
			// 
			this->dateTimePicker1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->dateTimePicker1->Location = System::Drawing::Point(48, 247);
			this->dateTimePicker1->MaxDate = System::DateTime(2021, 3, 1, 0, 0, 0, 0);
			this->dateTimePicker1->MinDate = System::DateTime(2021, 1, 1, 0, 0, 0, 0);
			this->dateTimePicker1->Name = L"dateTimePicker1";
			this->dateTimePicker1->Size = System::Drawing::Size(240, 22);
			this->dateTimePicker1->TabIndex = 1;
			// 
			// dateTimePicker2
			// 
			this->dateTimePicker2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->dateTimePicker2->Location = System::Drawing::Point(316, 247);
			this->dateTimePicker2->MaxDate = System::DateTime(2021, 3, 1, 0, 0, 0, 0);
			this->dateTimePicker2->MinDate = System::DateTime(2021, 1, 1, 0, 0, 0, 0);
			this->dateTimePicker2->Name = L"dateTimePicker2";
			this->dateTimePicker2->Size = System::Drawing::Size(240, 22);
			this->dateTimePicker2->TabIndex = 1;
			// 
			// SearchBtn
			// 
			this->SearchBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->SearchBtn->Location = System::Drawing::Point(481, 720);
			this->SearchBtn->Name = L"SearchBtn";
			this->SearchBtn->Size = System::Drawing::Size(75, 28);
			this->SearchBtn->TabIndex = 2;
			this->SearchBtn->Text = L"Search";
			this->SearchBtn->UseVisualStyleBackColor = true;
			this->SearchBtn->Click += gcnew System::EventHandler(this, &Room::SearchBtn_Click);
			// 
			// GardenViewChk
			// 
			this->GardenViewChk->AutoSize = true;
			this->GardenViewChk->BackColor = System::Drawing::Color::Transparent;
			this->GardenViewChk->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->GardenViewChk->Location = System::Drawing::Point(88, 120);
			this->GardenViewChk->Name = L"GardenViewChk";
			this->GardenViewChk->Size = System::Drawing::Size(107, 20);
			this->GardenViewChk->TabIndex = 3;
			this->GardenViewChk->Text = L"Garden view";
			this->GardenViewChk->UseVisualStyleBackColor = false;
			// 
			// BeachPavilionChk
			// 
			this->BeachPavilionChk->AutoSize = true;
			this->BeachPavilionChk->BackColor = System::Drawing::Color::Transparent;
			this->BeachPavilionChk->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BeachPavilionChk->Location = System::Drawing::Point(88, 159);
			this->BeachPavilionChk->Name = L"BeachPavilionChk";
			this->BeachPavilionChk->Size = System::Drawing::Size(97, 20);
			this->BeachPavilionChk->TabIndex = 3;
			this->BeachPavilionChk->Text = L"Beach view";
			this->BeachPavilionChk->UseVisualStyleBackColor = false;
			// 
			// BookBtn
			// 
			this->BookBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->BookBtn->Location = System::Drawing::Point(380, 332);
			this->BookBtn->Name = L"BookBtn";
			this->BookBtn->Size = System::Drawing::Size(75, 28);
			this->BookBtn->TabIndex = 2;
			this->BookBtn->Text = L"Book";
			this->BookBtn->UseVisualStyleBackColor = true;
			this->BookBtn->Click += gcnew System::EventHandler(this, &Room::BookBtn_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			this->dataGridView1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(39, 391);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersWidth = 51;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(517, 317);
			this->dataGridView1->TabIndex = 4;
			// 
			// RoomID
			// 
			this->RoomID->BackColor = System::Drawing::Color::White;
			this->RoomID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->RoomID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RoomID->Location = System::Drawing::Point(174, 332);
			this->RoomID->Name = L"RoomID";
			this->RoomID->Size = System::Drawing::Size(99, 20);
			this->RoomID->TabIndex = 5;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(177, 312);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(66, 16);
			this->label1->TabIndex = 6;
			this->label1->Text = L"Room ID";
			// 
			// ClientID
			// 
			this->ClientID->BackColor = System::Drawing::Color::White;
			this->ClientID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ClientID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ClientID->Location = System::Drawing::Point(48, 332);
			this->ClientID->Name = L"ClientID";
			this->ClientID->Size = System::Drawing::Size(99, 20);
			this->ClientID->TabIndex = 5;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(51, 312);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(66, 16);
			this->label2->TabIndex = 6;
			this->label2->Text = L"Client ID";
			// 
			// Update
			// 
			this->Update->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Update->Location = System::Drawing::Point(481, 332);
			this->Update->Name = L"Update";
			this->Update->Size = System::Drawing::Size(75, 28);
			this->Update->TabIndex = 11;
			this->Update->Text = L"Update";
			this->Update->UseVisualStyleBackColor = true;
			this->Update->Click += gcnew System::EventHandler(this, &Room::Update_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Transparent;
			this->label3->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(43, 29);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(135, 24);
			this->label3->TabIndex = 12;
			this->label3->Text = L"Type of room";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::Transparent;
			this->label4->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(60, 217);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(107, 18);
			this->label4->TabIndex = 12;
			this->label4->Text = L"Check in date";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::Transparent;
			this->label5->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(326, 217);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(117, 18);
			this->label5->TabIndex = 12;
			this->label5->Text = L"Check out date";
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel1->Location = System::Drawing::Point(48, 357);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(99, 3);
			this->panel1->TabIndex = 13;
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel2->Location = System::Drawing::Point(174, 357);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(99, 3);
			this->panel2->TabIndex = 13;
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->pictureBox1->Location = System::Drawing::Point(624, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(469, 762);
			this->pictureBox1->TabIndex = 14;
			this->pictureBox1->TabStop = false;
			// 
			// Room
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(1093, 762);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->Update);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->ClientID);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->RoomID);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->BeachPavilionChk);
			this->Controls->Add(this->GardenViewChk);
			this->Controls->Add(this->BookBtn);
			this->Controls->Add(this->SearchBtn);
			this->Controls->Add(this->dateTimePicker2);
			this->Controls->Add(this->dateTimePicker1);
			this->Controls->Add(this->ConferenceRoomChk);
			this->Controls->Add(this->BedroomChk);
			this->Name = L"Room";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Room";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->bindingSource1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	//private: System::Void Ok_Click(System::Object^ sender, System::EventArgs^ e) {
	//	if (BedroomChk->Checked)
	//	{
	//		
	//	}

	//	DateTime date = dateTimePicker1->Value;

	//	MessageBox::Show("Date " + date.Year);
	//	Room::Close();
	//}

		private: System::Void SearchBtn_Click(System::Object^ sender, System::EventArgs^ e) {

			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			DateTime datePicker1 = dateTimePicker1->Value;
			int year1 = datePicker1.Year;
			int month1 = datePicker1.Month;
			int day1 = datePicker1.Day;
			String^ check_in = "  " + year1 + "-" + month1 + "-" + day1 + "  ";

			DateTime datePicker2 = dateTimePicker2->Value;
			int year2 = datePicker2.Year;
			int month2 = datePicker2.Month;
			int day2 = datePicker2.Day;
			String^ check_out = "  " + year2 + "-" + month2 + "-" + day2 + "  ";

			if (BedroomChk->Checked)
			{
				MySqlDataAdapter^ sda = gcnew MySqlDataAdapter("SELECT room_id, date, status, type, garden_view, beach_pavilion FROM room_availability join room ON room.id=room_availability.room_id WHERE type='bedroom' AND garden_view=0 AND beach_pavilion=0 AND status=0 AND date BETWEEN '"+check_in+"' AND '"+check_out+"' ", con);

				DataTable^ dt = gcnew DataTable();
				sda->Fill(dt);

				bindingSource1->DataSource = dt;
				dataGridView1->DataSource = bindingSource1;

				if (GardenViewChk->Checked) {
					MySqlDataAdapter^ sda = gcnew MySqlDataAdapter("SELECT room_id, date, status, type, garden_view, beach_pavilion FROM room_availability join room ON room.id=room_availability.room_id WHERE type='bedroom' AND garden_view=1 AND beach_pavilion=0 AND status=0 AND date BETWEEN '" + check_in + "' AND '" + check_out + "' ", con);

					DataTable^ dt = gcnew DataTable();
					sda->Fill(dt);

					bindingSource1->DataSource = dt;
					dataGridView1->DataSource = bindingSource1;
				}

				if (BeachPavilionChk->Checked) {
					MySqlDataAdapter^ sda = gcnew MySqlDataAdapter("SELECT room_id, date, status, type, garden_view, beach_pavilion FROM room_availability join room ON room.id=room_availability.room_id WHERE type='bedroom' AND garden_view=0 AND beach_pavilion=1 AND status=0 AND date BETWEEN '" + check_in + "' AND '" + check_out + "' ", con);

					DataTable^ dt = gcnew DataTable();
					sda->Fill(dt);

					bindingSource1->DataSource = dt;
					dataGridView1->DataSource = bindingSource1;
				}

				if (GardenViewChk->Checked && BeachPavilionChk->Checked) {
					MySqlDataAdapter^ sda = gcnew MySqlDataAdapter("SELECT room_id, date, status, type, garden_view, beach_pavilion FROM room_availability join room ON room.id=room_availability.room_id WHERE type='bedroom' AND garden_view=1 AND beach_pavilion=1 AND status=0 AND date BETWEEN '" + check_in + "' AND '" + check_out + "' ", con);

					DataTable^ dt = gcnew DataTable();
					sda->Fill(dt);

					bindingSource1->DataSource = dt;
					dataGridView1->DataSource = bindingSource1;
				}
			}

			if (ConferenceRoomChk->Checked)
			{
				MySqlDataAdapter^ sda = gcnew MySqlDataAdapter("SELECT room_id, date, status, type, garden_view, beach_pavilion FROM room_availability join room ON room.id=room_availability.room_id WHERE type='conference room' AND status=0 AND date BETWEEN '" + check_in + "' AND '" + check_out + "' ", con);

				DataTable^ dt = gcnew DataTable();
				sda->Fill(dt);

				bindingSource1->DataSource = dt;
				dataGridView1->DataSource = bindingSource1;

			}

			if (BedroomChk->Checked && ConferenceRoomChk->Checked)
			{
				MySqlDataAdapter^ sda = gcnew MySqlDataAdapter("SELECT room_id, date, status, type, garden_view, beach_pavilion FROM room_availability join room ON room.id=room_availability.room_id WHERE status=0 AND date BETWEEN '" + check_in + "' AND '" + check_out + "' ", con);

				DataTable^ dt = gcnew DataTable();
				sda->Fill(dt);

				bindingSource1->DataSource = dt;
				dataGridView1->DataSource = bindingSource1;

			}
		}


		private: System::Void BookBtn_Click(System::Object^ sender, System::EventArgs^ e) {

			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			DateTime datePicker1 = dateTimePicker1->Value;
			int year1 = datePicker1.Year;
			int month1 = datePicker1.Month;
			int day1 = datePicker1.Day;
			String^ check_in = "  " + year1 + "-" + month1 + "-" + day1 + "  ";

			DateTime datePicker2 = dateTimePicker2->Value;
			int year2 = datePicker2.Year;
			int month2 = datePicker2.Month;
			int day2 = datePicker2.Day;
			String^ check_out = "  " + year2 + "-" + month2 + "-" + day2 + "  ";

			int clientid = Int32::Parse(ClientID->Text);

			int roomid = Int32::Parse(RoomID->Text);

			MySqlCommand^ cmd = gcnew MySqlCommand("UPDATE room_availability  SET client_id="+clientid+", status=1 WHERE room_id=" + roomid + " AND date BETWEEN '" + check_in + "' AND '" + check_out + "' ", con);
			MySqlDataReader^ dr;
			con->Open();
			dr = cmd->ExecuteReader();
			con->Close();
			MessageBox::Show("User info save");

			Room::Close();
		}


		private: System::Void Update_Click(System::Object^ sender, System::EventArgs^ e) {

			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			DateTime datePicker1 = dateTimePicker1->Value;
			int year1 = datePicker1.Year;
			int month1 = datePicker1.Month;
			int day1 = datePicker1.Day;
			String^ check_in = "  " + year1 + "-" + month1 + "-" + day1 + "  ";

			DateTime datePicker2 = dateTimePicker2->Value;
			int year2 = datePicker2.Year;
			int month2 = datePicker2.Month;
			int day2 = datePicker2.Day;
			String^ check_out = "  " + year2 + "-" + month2 + "-" + day2 + "  ";

			int clientid = Int32::Parse(ClientID->Text);

			int roomid = Int32::Parse(RoomID->Text);

			MySqlCommand^ cmd = gcnew MySqlCommand("UPDATE room_availability  SET client_id=" + clientid + ", status=1 WHERE room_id=" + roomid + " AND date BETWEEN '" + check_in + "' AND '" + check_out + "' ", con);
			MySqlDataReader^ dr;
			con->Open();
			dr = cmd->ExecuteReader();
			con->Close();
			MessageBox::Show("User info save");

			Room::Close();
		}
};
}
