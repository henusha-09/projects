#pragma once

namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for KidsCorner
	/// </summary>
	public ref class KidsCorner : public System::Windows::Forms::Form
	{
	public:
		KidsCorner(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~KidsCorner()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^ WaterActivities;
	protected:

	private: System::Windows::Forms::CheckBox^ Crafting;
	private: System::Windows::Forms::CheckBox^ Playground;
	private: System::Windows::Forms::Button^ OkBtn;
	protected:

	protected:



	private: System::Windows::Forms::CheckBox^ ArcadeGames;

	private: System::Windows::Forms::TextBox^ ClientID;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ Delete;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Panel^ panel1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(KidsCorner::typeid));
			this->WaterActivities = (gcnew System::Windows::Forms::CheckBox());
			this->Crafting = (gcnew System::Windows::Forms::CheckBox());
			this->Playground = (gcnew System::Windows::Forms::CheckBox());
			this->OkBtn = (gcnew System::Windows::Forms::Button());
			this->ArcadeGames = (gcnew System::Windows::Forms::CheckBox());
			this->ClientID = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->Delete = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// WaterActivities
			// 
			this->WaterActivities->AutoSize = true;
			this->WaterActivities->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->WaterActivities->Location = System::Drawing::Point(68, 98);
			this->WaterActivities->Name = L"WaterActivities";
			this->WaterActivities->Size = System::Drawing::Size(144, 24);
			this->WaterActivities->TabIndex = 1;
			this->WaterActivities->Text = L"Water Activities";
			this->WaterActivities->UseVisualStyleBackColor = true;
			// 
			// Crafting
			// 
			this->Crafting->AutoSize = true;
			this->Crafting->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Crafting->Location = System::Drawing::Point(68, 153);
			this->Crafting->Name = L"Crafting";
			this->Crafting->Size = System::Drawing::Size(91, 24);
			this->Crafting->TabIndex = 1;
			this->Crafting->Text = L"Crafting";
			this->Crafting->UseVisualStyleBackColor = true;
			// 
			// Playground
			// 
			this->Playground->AutoSize = true;
			this->Playground->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Playground->Location = System::Drawing::Point(68, 209);
			this->Playground->Name = L"Playground";
			this->Playground->Size = System::Drawing::Size(115, 24);
			this->Playground->TabIndex = 1;
			this->Playground->Text = L"Playground";
			this->Playground->UseVisualStyleBackColor = true;
			// 
			// OkBtn
			// 
			this->OkBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->OkBtn->Location = System::Drawing::Point(347, 676);
			this->OkBtn->Name = L"OkBtn";
			this->OkBtn->Size = System::Drawing::Size(75, 28);
			this->OkBtn->TabIndex = 3;
			this->OkBtn->Text = L"Ok";
			this->OkBtn->UseVisualStyleBackColor = true;
			this->OkBtn->Click += gcnew System::EventHandler(this, &KidsCorner::OkBtn_Click);
			// 
			// ArcadeGames
			// 
			this->ArcadeGames->AutoSize = true;
			this->ArcadeGames->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ArcadeGames->Location = System::Drawing::Point(68, 264);
			this->ArcadeGames->Name = L"ArcadeGames";
			this->ArcadeGames->Size = System::Drawing::Size(140, 24);
			this->ArcadeGames->TabIndex = 1;
			this->ArcadeGames->Text = L"Arcade games";
			this->ArcadeGames->UseVisualStyleBackColor = true;
			// 
			// ClientID
			// 
			this->ClientID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ClientID->Location = System::Drawing::Point(220, 676);
			this->ClientID->Name = L"ClientID";
			this->ClientID->Size = System::Drawing::Size(100, 15);
			this->ClientID->TabIndex = 4;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(220, 653);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(66, 16);
			this->label1->TabIndex = 5;
			this->label1->Text = L"Client ID";
			// 
			// Delete
			// 
			this->Delete->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Delete->Location = System::Drawing::Point(443, 676);
			this->Delete->Name = L"Delete";
			this->Delete->Size = System::Drawing::Size(75, 28);
			this->Delete->TabIndex = 13;
			this->Delete->Text = L"Delete";
			this->Delete->UseVisualStyleBackColor = true;
			this->Delete->Click += gcnew System::EventHandler(this, &KidsCorner::Delete_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(43, 47);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(75, 22);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Activity";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->pictureBox1->Location = System::Drawing::Point(584, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(464, 728);
			this->pictureBox1->TabIndex = 14;
			this->pictureBox1->TabStop = false;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel1->Location = System::Drawing::Point(220, 698);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(99, 3);
			this->panel1->TabIndex = 15;
			// 
			// KidsCorner
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1048, 728);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->Delete);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->ClientID);
			this->Controls->Add(this->OkBtn);
			this->Controls->Add(this->ArcadeGames);
			this->Controls->Add(this->Playground);
			this->Controls->Add(this->Crafting);
			this->Controls->Add(this->WaterActivities);
			this->Name = L"KidsCorner";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"KidsCorner";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void OkBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
		MySqlConnection^ con = gcnew MySqlConnection(constr);

		int clientid = Int32::Parse(ClientID->Text);

		if (WaterActivities->Checked)
		{
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO kidscorner_info (client_id, service) VALUES (" + clientid + ", 'Water Activities')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		if (Crafting->Checked)
		{
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO kidscorner_info (client_id, service) VALUES (" + clientid + ", 'Crafting')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		if (Playground->Checked)
		{
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO kidscorner_info (client_id, service) VALUES (" + clientid + ", 'Playground')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		if (ArcadeGames->Checked)
		{
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO kidscorner_info (client_id, service) VALUES (" + clientid + ", 'Arcade Games')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		KidsCorner::Close();
	}


	private: System::Void Delete_Click(System::Object^ sender, System::EventArgs^ e) {
		try
		{
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			int clientid = Int32::Parse(ClientID->Text);
			MySqlCommand^ cmd = gcnew MySqlCommand("delete from kidscorner_info where client_id=" + clientid + " ", con);

			con->Open();
			MySqlDataReader^ dr = cmd->ExecuteReader();
			MessageBox::Show("Deleted");
			con->Close();
		}
		catch (Exception^ ex)
		{
			MessageBox::Show(ex->Message);
		}
	}
};
}
