#pragma once

namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for Cleaning
	/// </summary>
	public ref class Cleaning : public System::Windows::Forms::Form
	{
	public:
		Cleaning(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Cleaning()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ OkBtn;
	protected:

	private: System::Windows::Forms::CheckBox^ Laundry;
	protected:

	private: System::Windows::Forms::CheckBox^ RoomCleaning;
	private: System::Windows::Forms::TextBox^ ClientID;
	private: System::Windows::Forms::Label^ ClientID1;
	private: System::Windows::Forms::TextBox^ Time;
	private: System::Windows::Forms::Label^ Time1;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker1;
	private: System::Windows::Forms::Button^ Delete;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Panel^ panel2;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Cleaning::typeid));
			this->OkBtn = (gcnew System::Windows::Forms::Button());
			this->Laundry = (gcnew System::Windows::Forms::CheckBox());
			this->RoomCleaning = (gcnew System::Windows::Forms::CheckBox());
			this->ClientID = (gcnew System::Windows::Forms::TextBox());
			this->ClientID1 = (gcnew System::Windows::Forms::Label());
			this->Time = (gcnew System::Windows::Forms::TextBox());
			this->Time1 = (gcnew System::Windows::Forms::Label());
			this->dateTimePicker1 = (gcnew System::Windows::Forms::DateTimePicker());
			this->Delete = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// OkBtn
			// 
			this->OkBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->OkBtn->Location = System::Drawing::Point(352, 614);
			this->OkBtn->Name = L"OkBtn";
			this->OkBtn->Size = System::Drawing::Size(75, 28);
			this->OkBtn->TabIndex = 7;
			this->OkBtn->Text = L"Ok";
			this->OkBtn->UseVisualStyleBackColor = true;
			this->OkBtn->Click += gcnew System::EventHandler(this, &Cleaning::OkBtn_Click);
			// 
			// Laundry
			// 
			this->Laundry->AutoSize = true;
			this->Laundry->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Laundry->Location = System::Drawing::Point(45, 136);
			this->Laundry->Name = L"Laundry";
			this->Laundry->Size = System::Drawing::Size(90, 24);
			this->Laundry->TabIndex = 3;
			this->Laundry->Text = L"Laundry";
			this->Laundry->UseVisualStyleBackColor = true;
			// 
			// RoomCleaning
			// 
			this->RoomCleaning->AutoSize = true;
			this->RoomCleaning->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RoomCleaning->Location = System::Drawing::Point(45, 88);
			this->RoomCleaning->Name = L"RoomCleaning";
			this->RoomCleaning->Size = System::Drawing::Size(142, 24);
			this->RoomCleaning->TabIndex = 4;
			this->RoomCleaning->Text = L"Room cleaning";
			this->RoomCleaning->UseVisualStyleBackColor = true;
			// 
			// ClientID
			// 
			this->ClientID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ClientID->Location = System::Drawing::Point(102, 614);
			this->ClientID->Name = L"ClientID";
			this->ClientID->Size = System::Drawing::Size(100, 15);
			this->ClientID->TabIndex = 8;
			// 
			// ClientID1
			// 
			this->ClientID1->AutoSize = true;
			this->ClientID1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ClientID1->Location = System::Drawing::Point(102, 591);
			this->ClientID1->Name = L"ClientID1";
			this->ClientID1->Size = System::Drawing::Size(66, 16);
			this->ClientID1->TabIndex = 9;
			this->ClientID1->Text = L"Client ID";
			// 
			// Time
			// 
			this->Time->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->Time->Location = System::Drawing::Point(219, 614);
			this->Time->Name = L"Time";
			this->Time->Size = System::Drawing::Size(100, 15);
			this->Time->TabIndex = 8;
			// 
			// Time1
			// 
			this->Time1->AutoSize = true;
			this->Time1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Time1->Location = System::Drawing::Point(219, 591);
			this->Time1->Name = L"Time1";
			this->Time1->Size = System::Drawing::Size(41, 16);
			this->Time1->TabIndex = 9;
			this->Time1->Text = L"Time";
			// 
			// dateTimePicker1
			// 
			this->dateTimePicker1->Location = System::Drawing::Point(31, 249);
			this->dateTimePicker1->Name = L"dateTimePicker1";
			this->dateTimePicker1->Size = System::Drawing::Size(244, 22);
			this->dateTimePicker1->TabIndex = 10;
			// 
			// Delete
			// 
			this->Delete->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Delete->Location = System::Drawing::Point(449, 614);
			this->Delete->Name = L"Delete";
			this->Delete->Size = System::Drawing::Size(75, 28);
			this->Delete->TabIndex = 13;
			this->Delete->Text = L"Delete";
			this->Delete->UseVisualStyleBackColor = true;
			this->Delete->Click += gcnew System::EventHandler(this, &Cleaning::Delete_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(31, 39);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(171, 22);
			this->label1->TabIndex = 9;
			this->label1->Text = L"Cleaning services";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(31, 225);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(40, 16);
			this->label2->TabIndex = 9;
			this->label2->Text = L"Date";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->pictureBox1->Location = System::Drawing::Point(561, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(445, 694);
			this->pictureBox1->TabIndex = 14;
			this->pictureBox1->TabStop = false;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel1->Location = System::Drawing::Point(102, 633);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(99, 3);
			this->panel1->TabIndex = 15;
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel2->Location = System::Drawing::Point(219, 633);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(99, 3);
			this->panel2->TabIndex = 15;
			// 
			// Cleaning
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1006, 694);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->Delete);
			this->Controls->Add(this->dateTimePicker1);
			this->Controls->Add(this->Time1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->ClientID1);
			this->Controls->Add(this->Time);
			this->Controls->Add(this->ClientID);
			this->Controls->Add(this->OkBtn);
			this->Controls->Add(this->Laundry);
			this->Controls->Add(this->RoomCleaning);
			this->Name = L"Cleaning";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Cleaning";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		private: System::Void OkBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			int clientid = Int32::Parse(ClientID->Text);

			DateTime datePicker = dateTimePicker1->Value;
			int year = datePicker.Year;
			int month = datePicker.Month;
			int day = datePicker.Day;
			String^ date = "  " + year + "-" + month + "-" + day + "  ";

			String^ time = Time->Text;

			if (RoomCleaning->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO cleaning_info (client_id, service, date, time) VALUES (" + clientid + ", 'Room Cleaning', '" + date + "', '" + time + "')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Laundry->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO cleaning_info (client_id, service, date, time) VALUES (" + clientid + ", 'Laundry', '" + date + "', '" + time + "')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			Cleaning::Close();
		}

		private: System::Void Delete_Click(System::Object^ sender, System::EventArgs^ e) {

			try
			{
				String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
				MySqlConnection^ con = gcnew MySqlConnection(constr);

				int clientid = Int32::Parse(ClientID->Text);
				MySqlCommand^ cmd = gcnew MySqlCommand("delete from cleaning_info where client_id=" + clientid + " ", con);

				con->Open();
				MySqlDataReader^ dr = cmd->ExecuteReader();
				MessageBox::Show("Deleted");
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}

			Cleaning::Close();
		}
};
}
