#pragma once

namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for Flight
	/// </summary>
	public ref class Flight : public System::Windows::Forms::Form
	{
	public:
		Flight(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Flight()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:

	private: System::Windows::Forms::DateTimePicker^ dateTimePicker1;
	private: System::Windows::Forms::Button^ SearchBtn;

	private: System::Windows::Forms::TextBox^ ClientID;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::DataGridView^ dataGridView1;


	private: System::Windows::Forms::BindingSource^ bindingSource1;
	private: System::Windows::Forms::Button^ BookBtn;
	private: System::Windows::Forms::TextBox^ TicketID;
	private: System::Windows::Forms::Label^ TicketID1;
	private: System::Windows::Forms::Button^ DeleteBtn;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::ComboBox^ comboBox1;
	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Flight::typeid));
			this->dateTimePicker1 = (gcnew System::Windows::Forms::DateTimePicker());
			this->SearchBtn = (gcnew System::Windows::Forms::Button());
			this->ClientID = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->bindingSource1 = (gcnew System::Windows::Forms::BindingSource(this->components));
			this->BookBtn = (gcnew System::Windows::Forms::Button());
			this->TicketID = (gcnew System::Windows::Forms::TextBox());
			this->TicketID1 = (gcnew System::Windows::Forms::Label());
			this->DeleteBtn = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->bindingSource1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// dateTimePicker1
			// 
			this->dateTimePicker1->Location = System::Drawing::Point(212, 429);
			this->dateTimePicker1->Name = L"dateTimePicker1";
			this->dateTimePicker1->Size = System::Drawing::Size(256, 22);
			this->dateTimePicker1->TabIndex = 2;
			// 
			// SearchBtn
			// 
			this->SearchBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->SearchBtn->Location = System::Drawing::Point(542, 331);
			this->SearchBtn->Name = L"SearchBtn";
			this->SearchBtn->Size = System::Drawing::Size(75, 27);
			this->SearchBtn->TabIndex = 3;
			this->SearchBtn->Text = L"Search";
			this->SearchBtn->UseVisualStyleBackColor = true;
			this->SearchBtn->Click += gcnew System::EventHandler(this, &Flight::SearchBtn_Click);
			// 
			// ClientID
			// 
			this->ClientID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ClientID->Location = System::Drawing::Point(206, 672);
			this->ClientID->Name = L"ClientID";
			this->ClientID->Size = System::Drawing::Size(100, 15);
			this->ClientID->TabIndex = 4;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(209, 652);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(66, 16);
			this->label1->TabIndex = 5;
			this->label1->Text = L"Client ID";
			// 
			// dataGridView1
			// 
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(37, 41);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersWidth = 51;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(580, 272);
			this->dataGridView1->TabIndex = 6;
			// 
			// BookBtn
			// 
			this->BookBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->BookBtn->Location = System::Drawing::Point(451, 670);
			this->BookBtn->Name = L"BookBtn";
			this->BookBtn->Size = System::Drawing::Size(75, 27);
			this->BookBtn->TabIndex = 3;
			this->BookBtn->Text = L"Book";
			this->BookBtn->UseVisualStyleBackColor = true;
			this->BookBtn->Click += gcnew System::EventHandler(this, &Flight::BookBtn_Click);
			// 
			// TicketID
			// 
			this->TicketID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->TicketID->Location = System::Drawing::Point(329, 672);
			this->TicketID->Name = L"TicketID";
			this->TicketID->Size = System::Drawing::Size(100, 15);
			this->TicketID->TabIndex = 4;
			// 
			// TicketID1
			// 
			this->TicketID1->AutoSize = true;
			this->TicketID1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->TicketID1->Location = System::Drawing::Point(332, 652);
			this->TicketID1->Name = L"TicketID1";
			this->TicketID1->Size = System::Drawing::Size(65, 16);
			this->TicketID1->TabIndex = 5;
			this->TicketID1->Text = L"Ticket ID";
			// 
			// DeleteBtn
			// 
			this->DeleteBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->DeleteBtn->Location = System::Drawing::Point(542, 670);
			this->DeleteBtn->Name = L"DeleteBtn";
			this->DeleteBtn->Size = System::Drawing::Size(75, 27);
			this->DeleteBtn->TabIndex = 3;
			this->DeleteBtn->Text = L"Delete";
			this->DeleteBtn->UseVisualStyleBackColor = true;
			this->DeleteBtn->Click += gcnew System::EventHandler(this, &Flight::DeleteBtn_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(44, 405);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(85, 16);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Destination";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(209, 409);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(40, 16);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Date";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->pictureBox1->Location = System::Drawing::Point(731, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(461, 722);
			this->pictureBox1->TabIndex = 8;
			this->pictureBox1->TabStop = false;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel1->Location = System::Drawing::Point(207, 694);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(99, 3);
			this->panel1->TabIndex = 14;
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel2->Location = System::Drawing::Point(329, 694);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(99, 3);
			this->panel2->TabIndex = 14;
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(6) {
				L"Rodrigues", L"Paris", L"London", L"Dubai", L"Reunion",
					L"Australia"
			});
			this->comboBox1->Location = System::Drawing::Point(37, 427);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(121, 24);
			this->comboBox1->TabIndex = 15;
			// 
			// Flight
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1192, 722);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->TicketID1);
			this->Controls->Add(this->TicketID);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->ClientID);
			this->Controls->Add(this->DeleteBtn);
			this->Controls->Add(this->BookBtn);
			this->Controls->Add(this->SearchBtn);
			this->Controls->Add(this->dateTimePicker1);
			this->Name = L"Flight";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Flight";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->bindingSource1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void SearchBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
		MySqlConnection^ con = gcnew MySqlConnection(constr);

		DateTime datePicker = dateTimePicker1->Value;
		int year = datePicker.Year;
		int month = datePicker.Month;
		int day = datePicker.Day;
		String^ date = "  " + year + "-" + month + "-" + day + "  ";
		
		MySqlDataAdapter^ sda = gcnew MySqlDataAdapter("SELECT ticket_id, destination, date, time FROM flight_info where destination='"+comboBox1->Text+"' AND status=0 AND date='" + date + "' ", con);

		DataTable^ dt = gcnew DataTable();
		sda->Fill(dt);

		bindingSource1->DataSource = dt;
		dataGridView1->DataSource = bindingSource1;
	}






	private: System::Void BookBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
		MySqlConnection^ con = gcnew MySqlConnection(constr);

		DateTime datePicker = dateTimePicker1->Value;
		int year = datePicker.Year;
		int month = datePicker.Month;
		int day = datePicker.Day;
		String^ date = "  " + year + "-" + month + "-" + day + "  ";

		int clientid = Int32::Parse(ClientID->Text);

		int ticketid = Int32::Parse(TicketID->Text);

		MySqlCommand^ cmd = gcnew MySqlCommand("UPDATE flight_info  SET client_id=" + clientid + ", status=1 WHERE ticket_id=" + ticketid + " AND date='" + date + "' ", con);
		MySqlDataReader^ dr;
		con->Open();
		dr = cmd->ExecuteReader();
		con->Close();
		MessageBox::Show("User info save");

		Flight::Close();
	}


	private: System::Void DeleteBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
		MySqlConnection^ con = gcnew MySqlConnection(constr);

		int clientid = Int32::Parse(ClientID->Text);
		MySqlCommand^ cmd = gcnew MySqlCommand("UPDATE flight_info  SET client_id=NULL, status=0 WHERE client_id=" + clientid + "", con);

		con->Open();
		MySqlDataReader^ dr = cmd->ExecuteReader();
		con->Close();

	}
};
}
