#include "Login.h"


//using namespace System;
//using namespace System::Windows::Forms;
//[STAThreadAttribute]
//void main(array<String^>^ args) {
//	Application::EnableVisualStyles();
//	Application::SetCompatibleTextRenderingDefault(false);
//	HotelReservation::Login form;
//	Application::Run(% form);
//
//}