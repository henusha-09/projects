#pragma once

namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for RoomService
	/// </summary>
	public ref class RoomService : public System::Windows::Forms::Form
	{
	public:
		RoomService(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~RoomService()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^ ChickenBurger;
	protected:

	protected:
	private: System::Windows::Forms::NumericUpDown^ numericUpDown1;
	private: System::Windows::Forms::CheckBox^ AlfredoPasta;

	private: System::Windows::Forms::NumericUpDown^ numericUpDown2;
	private: System::Windows::Forms::CheckBox^ LambLasagna;
	private: System::Windows::Forms::CheckBox^ SeaFoodPlater;



	private: System::Windows::Forms::NumericUpDown^ numericUpDown3;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown4;
	private: System::Windows::Forms::CheckBox^ ChickenSalad;
	private: System::Windows::Forms::CheckBox^ SeafoodPaella;


	private: System::Windows::Forms::CheckBox^ BeefSandwich;
	private: System::Windows::Forms::CheckBox^ CrabSoup;


	private: System::Windows::Forms::NumericUpDown^ numericUpDown5;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown6;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown7;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown8;
	private: System::Windows::Forms::CheckBox^ Sushi;

	private: System::Windows::Forms::CheckBox^ BeefSteak;
	private: System::Windows::Forms::CheckBox^ TandooriChicken;


	private: System::Windows::Forms::NumericUpDown^ numericUpDown9;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown10;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown11;
	private: System::Windows::Forms::GroupBox^ groupBox1;
	private: System::Windows::Forms::GroupBox^ groupBox2;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown12;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown13;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown14;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown15;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown16;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown17;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown18;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown19;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown20;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown21;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown22;
	private: System::Windows::Forms::CheckBox^ Mojito;

	private: System::Windows::Forms::CheckBox^ Wine;

	private: System::Windows::Forms::CheckBox^ Sprite;
	private: System::Windows::Forms::CheckBox^ Whiskey;


	private: System::Windows::Forms::CheckBox^ Limonade;
	private: System::Windows::Forms::CheckBox^ Champagne;


	private: System::Windows::Forms::CheckBox^ Fanta;
	private: System::Windows::Forms::CheckBox^ Beer;


	private: System::Windows::Forms::CheckBox^ SparklingWater;
	private: System::Windows::Forms::CheckBox^ FreshJuice;


	private: System::Windows::Forms::CheckBox^ CocaCola;
	private: System::Windows::Forms::Button^ OkBtn;
	private: System::Windows::Forms::TextBox^ ClientID;





	private: System::Windows::Forms::GroupBox^ groupBox3;


	private: System::Windows::Forms::NumericUpDown^ numericUpDown25;


	private: System::Windows::Forms::NumericUpDown^ numericUpDown28;


	private: System::Windows::Forms::NumericUpDown^ numericUpDown31;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown32;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown33;


	private: System::Windows::Forms::CheckBox^ VeggiePizza;



	private: System::Windows::Forms::CheckBox^ VeggieBurger;

	private: System::Windows::Forms::CheckBox^ MacNCheese;
	private: System::Windows::Forms::CheckBox^ VeggieSalad;
	private: System::Windows::Forms::CheckBox^ CheeseSandwich;
private: System::Windows::Forms::GroupBox^ groupBox4;
private: System::Windows::Forms::NumericUpDown^ numericUpDown23;
private: System::Windows::Forms::NumericUpDown^ numericUpDown24;
private: System::Windows::Forms::NumericUpDown^ numericUpDown26;
private: System::Windows::Forms::NumericUpDown^ numericUpDown29;
private: System::Windows::Forms::CheckBox^ Pastries;
private: System::Windows::Forms::CheckBox^ CheeseCake;
private: System::Windows::Forms::CheckBox^ Pudding;
private: System::Windows::Forms::CheckBox^ Brownie;
private: System::Windows::Forms::Label^ ClientID1;
private: System::Windows::Forms::Button^ Delete;
private: System::Windows::Forms::PictureBox^ pictureBox1;
private: System::Windows::Forms::Panel^ panel1;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(RoomService::typeid));
			this->ChickenBurger = (gcnew System::Windows::Forms::CheckBox());
			this->numericUpDown1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->AlfredoPasta = (gcnew System::Windows::Forms::CheckBox());
			this->numericUpDown2 = (gcnew System::Windows::Forms::NumericUpDown());
			this->LambLasagna = (gcnew System::Windows::Forms::CheckBox());
			this->SeaFoodPlater = (gcnew System::Windows::Forms::CheckBox());
			this->numericUpDown3 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown4 = (gcnew System::Windows::Forms::NumericUpDown());
			this->ChickenSalad = (gcnew System::Windows::Forms::CheckBox());
			this->SeafoodPaella = (gcnew System::Windows::Forms::CheckBox());
			this->BeefSandwich = (gcnew System::Windows::Forms::CheckBox());
			this->CrabSoup = (gcnew System::Windows::Forms::CheckBox());
			this->numericUpDown5 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown6 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown7 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown8 = (gcnew System::Windows::Forms::NumericUpDown());
			this->Sushi = (gcnew System::Windows::Forms::CheckBox());
			this->BeefSteak = (gcnew System::Windows::Forms::CheckBox());
			this->TandooriChicken = (gcnew System::Windows::Forms::CheckBox());
			this->numericUpDown9 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown10 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown11 = (gcnew System::Windows::Forms::NumericUpDown());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->numericUpDown12 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown13 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown14 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown15 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown16 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown17 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown18 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown19 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown20 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown21 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown22 = (gcnew System::Windows::Forms::NumericUpDown());
			this->Mojito = (gcnew System::Windows::Forms::CheckBox());
			this->Wine = (gcnew System::Windows::Forms::CheckBox());
			this->Sprite = (gcnew System::Windows::Forms::CheckBox());
			this->Whiskey = (gcnew System::Windows::Forms::CheckBox());
			this->Limonade = (gcnew System::Windows::Forms::CheckBox());
			this->Champagne = (gcnew System::Windows::Forms::CheckBox());
			this->Fanta = (gcnew System::Windows::Forms::CheckBox());
			this->Beer = (gcnew System::Windows::Forms::CheckBox());
			this->SparklingWater = (gcnew System::Windows::Forms::CheckBox());
			this->FreshJuice = (gcnew System::Windows::Forms::CheckBox());
			this->CocaCola = (gcnew System::Windows::Forms::CheckBox());
			this->OkBtn = (gcnew System::Windows::Forms::Button());
			this->ClientID = (gcnew System::Windows::Forms::TextBox());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->numericUpDown25 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown28 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown31 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown32 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown33 = (gcnew System::Windows::Forms::NumericUpDown());
			this->VeggiePizza = (gcnew System::Windows::Forms::CheckBox());
			this->VeggieBurger = (gcnew System::Windows::Forms::CheckBox());
			this->MacNCheese = (gcnew System::Windows::Forms::CheckBox());
			this->VeggieSalad = (gcnew System::Windows::Forms::CheckBox());
			this->CheeseSandwich = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->numericUpDown23 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown24 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown26 = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericUpDown29 = (gcnew System::Windows::Forms::NumericUpDown());
			this->Pastries = (gcnew System::Windows::Forms::CheckBox());
			this->CheeseCake = (gcnew System::Windows::Forms::CheckBox());
			this->Pudding = (gcnew System::Windows::Forms::CheckBox());
			this->Brownie = (gcnew System::Windows::Forms::CheckBox());
			this->ClientID1 = (gcnew System::Windows::Forms::Label());
			this->Delete = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown5))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown6))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown7))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown8))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown9))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown10))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown11))->BeginInit();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown12))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown13))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown14))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown15))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown16))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown17))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown18))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown19))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown20))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown21))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown22))->BeginInit();
			this->groupBox3->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown25))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown28))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown31))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown32))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown33))->BeginInit();
			this->groupBox4->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown23))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown24))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown26))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown29))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// ChickenBurger
			// 
			this->ChickenBurger->AutoSize = true;
			this->ChickenBurger->Location = System::Drawing::Point(34, 42);
			this->ChickenBurger->Name = L"ChickenBurger";
			this->ChickenBurger->Size = System::Drawing::Size(127, 21);
			this->ChickenBurger->TabIndex = 0;
			this->ChickenBurger->Text = L"Chicken Burger";
			this->ChickenBurger->UseVisualStyleBackColor = true;
			// 
			// numericUpDown1
			// 
			this->numericUpDown1->Location = System::Drawing::Point(209, 42);
			this->numericUpDown1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown1->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown1->Name = L"numericUpDown1";
			this->numericUpDown1->Size = System::Drawing::Size(67, 22);
			this->numericUpDown1->TabIndex = 1;
			this->numericUpDown1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// AlfredoPasta
			// 
			this->AlfredoPasta->AutoSize = true;
			this->AlfredoPasta->Location = System::Drawing::Point(34, 81);
			this->AlfredoPasta->Name = L"AlfredoPasta";
			this->AlfredoPasta->Size = System::Drawing::Size(115, 21);
			this->AlfredoPasta->TabIndex = 0;
			this->AlfredoPasta->Text = L"Alfredo Pasta";
			this->AlfredoPasta->UseVisualStyleBackColor = true;
			// 
			// numericUpDown2
			// 
			this->numericUpDown2->Location = System::Drawing::Point(209, 81);
			this->numericUpDown2->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown2->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown2->Name = L"numericUpDown2";
			this->numericUpDown2->Size = System::Drawing::Size(67, 22);
			this->numericUpDown2->TabIndex = 1;
			this->numericUpDown2->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// LambLasagna
			// 
			this->LambLasagna->AutoSize = true;
			this->LambLasagna->Location = System::Drawing::Point(34, 120);
			this->LambLasagna->Name = L"LambLasagna";
			this->LambLasagna->Size = System::Drawing::Size(124, 21);
			this->LambLasagna->TabIndex = 0;
			this->LambLasagna->Text = L"Lamb Lasagna";
			this->LambLasagna->UseVisualStyleBackColor = true;
			// 
			// SeaFoodPlater
			// 
			this->SeaFoodPlater->AutoSize = true;
			this->SeaFoodPlater->Location = System::Drawing::Point(34, 159);
			this->SeaFoodPlater->Name = L"SeaFoodPlater";
			this->SeaFoodPlater->Size = System::Drawing::Size(128, 21);
			this->SeaFoodPlater->TabIndex = 0;
			this->SeaFoodPlater->Text = L"Seafood Platter";
			this->SeaFoodPlater->UseVisualStyleBackColor = true;
			// 
			// numericUpDown3
			// 
			this->numericUpDown3->Location = System::Drawing::Point(209, 120);
			this->numericUpDown3->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown3->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown3->Name = L"numericUpDown3";
			this->numericUpDown3->Size = System::Drawing::Size(67, 22);
			this->numericUpDown3->TabIndex = 1;
			this->numericUpDown3->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown4
			// 
			this->numericUpDown4->Location = System::Drawing::Point(209, 159);
			this->numericUpDown4->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown4->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown4->Name = L"numericUpDown4";
			this->numericUpDown4->Size = System::Drawing::Size(67, 22);
			this->numericUpDown4->TabIndex = 1;
			this->numericUpDown4->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// ChickenSalad
			// 
			this->ChickenSalad->AutoSize = true;
			this->ChickenSalad->Location = System::Drawing::Point(34, 197);
			this->ChickenSalad->Name = L"ChickenSalad";
			this->ChickenSalad->Size = System::Drawing::Size(120, 21);
			this->ChickenSalad->TabIndex = 0;
			this->ChickenSalad->Text = L"Chicken Salad";
			this->ChickenSalad->UseVisualStyleBackColor = true;
			// 
			// SeafoodPaella
			// 
			this->SeafoodPaella->AutoSize = true;
			this->SeafoodPaella->Location = System::Drawing::Point(34, 275);
			this->SeafoodPaella->Name = L"SeafoodPaella";
			this->SeafoodPaella->Size = System::Drawing::Size(126, 21);
			this->SeafoodPaella->TabIndex = 0;
			this->SeafoodPaella->Text = L"Seafood Paella";
			this->SeafoodPaella->UseVisualStyleBackColor = true;
			// 
			// BeefSandwich
			// 
			this->BeefSandwich->AutoSize = true;
			this->BeefSandwich->Location = System::Drawing::Point(34, 236);
			this->BeefSandwich->Name = L"BeefSandwich";
			this->BeefSandwich->Size = System::Drawing::Size(123, 21);
			this->BeefSandwich->TabIndex = 0;
			this->BeefSandwich->Text = L"Beef Sandwich";
			this->BeefSandwich->UseVisualStyleBackColor = true;
			// 
			// CrabSoup
			// 
			this->CrabSoup->AutoSize = true;
			this->CrabSoup->Location = System::Drawing::Point(34, 314);
			this->CrabSoup->Name = L"CrabSoup";
			this->CrabSoup->Size = System::Drawing::Size(127, 21);
			this->CrabSoup->TabIndex = 0;
			this->CrabSoup->Text = L"She-Crab Soup";
			this->CrabSoup->UseVisualStyleBackColor = true;
			// 
			// numericUpDown5
			// 
			this->numericUpDown5->Location = System::Drawing::Point(209, 197);
			this->numericUpDown5->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown5->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown5->Name = L"numericUpDown5";
			this->numericUpDown5->Size = System::Drawing::Size(67, 22);
			this->numericUpDown5->TabIndex = 1;
			this->numericUpDown5->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown6
			// 
			this->numericUpDown6->Location = System::Drawing::Point(209, 275);
			this->numericUpDown6->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown6->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown6->Name = L"numericUpDown6";
			this->numericUpDown6->Size = System::Drawing::Size(67, 22);
			this->numericUpDown6->TabIndex = 1;
			this->numericUpDown6->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown7
			// 
			this->numericUpDown7->Location = System::Drawing::Point(209, 236);
			this->numericUpDown7->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown7->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown7->Name = L"numericUpDown7";
			this->numericUpDown7->Size = System::Drawing::Size(67, 22);
			this->numericUpDown7->TabIndex = 1;
			this->numericUpDown7->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown8
			// 
			this->numericUpDown8->Location = System::Drawing::Point(209, 314);
			this->numericUpDown8->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown8->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown8->Name = L"numericUpDown8";
			this->numericUpDown8->Size = System::Drawing::Size(67, 22);
			this->numericUpDown8->TabIndex = 1;
			this->numericUpDown8->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// Sushi
			// 
			this->Sushi->AutoSize = true;
			this->Sushi->Location = System::Drawing::Point(34, 392);
			this->Sushi->Name = L"Sushi";
			this->Sushi->Size = System::Drawing::Size(110, 21);
			this->Sushi->TabIndex = 0;
			this->Sushi->Text = L"Sushi Platter";
			this->Sushi->UseVisualStyleBackColor = true;
			// 
			// BeefSteak
			// 
			this->BeefSteak->AutoSize = true;
			this->BeefSteak->Location = System::Drawing::Point(34, 353);
			this->BeefSteak->Name = L"BeefSteak";
			this->BeefSteak->Size = System::Drawing::Size(99, 21);
			this->BeefSteak->TabIndex = 0;
			this->BeefSteak->Text = L"Beef Steak";
			this->BeefSteak->UseVisualStyleBackColor = true;
			// 
			// TandooriChicken
			// 
			this->TandooriChicken->AutoSize = true;
			this->TandooriChicken->Location = System::Drawing::Point(34, 431);
			this->TandooriChicken->Name = L"TandooriChicken";
			this->TandooriChicken->Size = System::Drawing::Size(141, 21);
			this->TandooriChicken->TabIndex = 0;
			this->TandooriChicken->Text = L"Tandoori Chicken";
			this->TandooriChicken->UseVisualStyleBackColor = true;
			// 
			// numericUpDown9
			// 
			this->numericUpDown9->Location = System::Drawing::Point(209, 392);
			this->numericUpDown9->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown9->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown9->Name = L"numericUpDown9";
			this->numericUpDown9->Size = System::Drawing::Size(67, 22);
			this->numericUpDown9->TabIndex = 1;
			this->numericUpDown9->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown10
			// 
			this->numericUpDown10->Location = System::Drawing::Point(209, 353);
			this->numericUpDown10->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown10->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown10->Name = L"numericUpDown10";
			this->numericUpDown10->Size = System::Drawing::Size(67, 22);
			this->numericUpDown10->TabIndex = 1;
			this->numericUpDown10->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown11
			// 
			this->numericUpDown11->Location = System::Drawing::Point(209, 431);
			this->numericUpDown11->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown11->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown11->Name = L"numericUpDown11";
			this->numericUpDown11->Size = System::Drawing::Size(67, 22);
			this->numericUpDown11->TabIndex = 1;
			this->numericUpDown11->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->numericUpDown11);
			this->groupBox1->Controls->Add(this->numericUpDown8);
			this->groupBox1->Controls->Add(this->numericUpDown4);
			this->groupBox1->Controls->Add(this->numericUpDown10);
			this->groupBox1->Controls->Add(this->numericUpDown7);
			this->groupBox1->Controls->Add(this->numericUpDown2);
			this->groupBox1->Controls->Add(this->numericUpDown9);
			this->groupBox1->Controls->Add(this->numericUpDown6);
			this->groupBox1->Controls->Add(this->numericUpDown3);
			this->groupBox1->Controls->Add(this->numericUpDown5);
			this->groupBox1->Controls->Add(this->numericUpDown1);
			this->groupBox1->Controls->Add(this->TandooriChicken);
			this->groupBox1->Controls->Add(this->CrabSoup);
			this->groupBox1->Controls->Add(this->SeaFoodPlater);
			this->groupBox1->Controls->Add(this->BeefSteak);
			this->groupBox1->Controls->Add(this->BeefSandwich);
			this->groupBox1->Controls->Add(this->Sushi);
			this->groupBox1->Controls->Add(this->AlfredoPasta);
			this->groupBox1->Controls->Add(this->SeafoodPaella);
			this->groupBox1->Controls->Add(this->LambLasagna);
			this->groupBox1->Controls->Add(this->ChickenSalad);
			this->groupBox1->Controls->Add(this->ChickenBurger);
			this->groupBox1->Location = System::Drawing::Point(25, 47);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(323, 481);
			this->groupBox1->TabIndex = 2;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Food";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->numericUpDown12);
			this->groupBox2->Controls->Add(this->numericUpDown13);
			this->groupBox2->Controls->Add(this->numericUpDown14);
			this->groupBox2->Controls->Add(this->numericUpDown15);
			this->groupBox2->Controls->Add(this->numericUpDown16);
			this->groupBox2->Controls->Add(this->numericUpDown17);
			this->groupBox2->Controls->Add(this->numericUpDown18);
			this->groupBox2->Controls->Add(this->numericUpDown19);
			this->groupBox2->Controls->Add(this->numericUpDown20);
			this->groupBox2->Controls->Add(this->numericUpDown21);
			this->groupBox2->Controls->Add(this->numericUpDown22);
			this->groupBox2->Controls->Add(this->Mojito);
			this->groupBox2->Controls->Add(this->Wine);
			this->groupBox2->Controls->Add(this->Sprite);
			this->groupBox2->Controls->Add(this->Whiskey);
			this->groupBox2->Controls->Add(this->Limonade);
			this->groupBox2->Controls->Add(this->Champagne);
			this->groupBox2->Controls->Add(this->Fanta);
			this->groupBox2->Controls->Add(this->Beer);
			this->groupBox2->Controls->Add(this->SparklingWater);
			this->groupBox2->Controls->Add(this->FreshJuice);
			this->groupBox2->Controls->Add(this->CocaCola);
			this->groupBox2->Location = System::Drawing::Point(715, 47);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(323, 481);
			this->groupBox2->TabIndex = 2;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Drinks";
			// 
			// numericUpDown12
			// 
			this->numericUpDown12->Location = System::Drawing::Point(209, 431);
			this->numericUpDown12->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown12->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown12->Name = L"numericUpDown12";
			this->numericUpDown12->Size = System::Drawing::Size(67, 22);
			this->numericUpDown12->TabIndex = 1;
			this->numericUpDown12->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown13
			// 
			this->numericUpDown13->Location = System::Drawing::Point(209, 314);
			this->numericUpDown13->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown13->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown13->Name = L"numericUpDown13";
			this->numericUpDown13->Size = System::Drawing::Size(67, 22);
			this->numericUpDown13->TabIndex = 1;
			this->numericUpDown13->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown14
			// 
			this->numericUpDown14->Location = System::Drawing::Point(209, 159);
			this->numericUpDown14->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown14->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown14->Name = L"numericUpDown14";
			this->numericUpDown14->Size = System::Drawing::Size(67, 22);
			this->numericUpDown14->TabIndex = 1;
			this->numericUpDown14->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown15
			// 
			this->numericUpDown15->Location = System::Drawing::Point(209, 353);
			this->numericUpDown15->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown15->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown15->Name = L"numericUpDown15";
			this->numericUpDown15->Size = System::Drawing::Size(67, 22);
			this->numericUpDown15->TabIndex = 1;
			this->numericUpDown15->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown16
			// 
			this->numericUpDown16->Location = System::Drawing::Point(209, 236);
			this->numericUpDown16->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown16->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown16->Name = L"numericUpDown16";
			this->numericUpDown16->Size = System::Drawing::Size(67, 22);
			this->numericUpDown16->TabIndex = 1;
			this->numericUpDown16->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown17
			// 
			this->numericUpDown17->Location = System::Drawing::Point(209, 81);
			this->numericUpDown17->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown17->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown17->Name = L"numericUpDown17";
			this->numericUpDown17->Size = System::Drawing::Size(67, 22);
			this->numericUpDown17->TabIndex = 1;
			this->numericUpDown17->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown18
			// 
			this->numericUpDown18->Location = System::Drawing::Point(209, 392);
			this->numericUpDown18->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown18->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown18->Name = L"numericUpDown18";
			this->numericUpDown18->Size = System::Drawing::Size(67, 22);
			this->numericUpDown18->TabIndex = 1;
			this->numericUpDown18->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown19
			// 
			this->numericUpDown19->Location = System::Drawing::Point(209, 275);
			this->numericUpDown19->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown19->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown19->Name = L"numericUpDown19";
			this->numericUpDown19->Size = System::Drawing::Size(67, 22);
			this->numericUpDown19->TabIndex = 1;
			this->numericUpDown19->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown20
			// 
			this->numericUpDown20->Location = System::Drawing::Point(209, 120);
			this->numericUpDown20->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown20->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown20->Name = L"numericUpDown20";
			this->numericUpDown20->Size = System::Drawing::Size(67, 22);
			this->numericUpDown20->TabIndex = 1;
			this->numericUpDown20->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown21
			// 
			this->numericUpDown21->Location = System::Drawing::Point(209, 197);
			this->numericUpDown21->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown21->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown21->Name = L"numericUpDown21";
			this->numericUpDown21->Size = System::Drawing::Size(67, 22);
			this->numericUpDown21->TabIndex = 1;
			this->numericUpDown21->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown22
			// 
			this->numericUpDown22->Location = System::Drawing::Point(209, 42);
			this->numericUpDown22->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown22->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown22->Name = L"numericUpDown22";
			this->numericUpDown22->Size = System::Drawing::Size(67, 22);
			this->numericUpDown22->TabIndex = 1;
			this->numericUpDown22->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// Mojito
			// 
			this->Mojito->AutoSize = true;
			this->Mojito->Location = System::Drawing::Point(34, 431);
			this->Mojito->Name = L"Mojito";
			this->Mojito->Size = System::Drawing::Size(67, 21);
			this->Mojito->TabIndex = 0;
			this->Mojito->Text = L"Mojito";
			this->Mojito->UseVisualStyleBackColor = true;
			// 
			// Wine
			// 
			this->Wine->AutoSize = true;
			this->Wine->Location = System::Drawing::Point(34, 314);
			this->Wine->Name = L"Wine";
			this->Wine->Size = System::Drawing::Size(62, 21);
			this->Wine->TabIndex = 0;
			this->Wine->Text = L"Wine";
			this->Wine->UseVisualStyleBackColor = true;
			// 
			// Sprite
			// 
			this->Sprite->AutoSize = true;
			this->Sprite->Location = System::Drawing::Point(34, 159);
			this->Sprite->Name = L"Sprite";
			this->Sprite->Size = System::Drawing::Size(67, 21);
			this->Sprite->TabIndex = 0;
			this->Sprite->Text = L"Sprite";
			this->Sprite->UseVisualStyleBackColor = true;
			// 
			// Whiskey
			// 
			this->Whiskey->AutoSize = true;
			this->Whiskey->Location = System::Drawing::Point(34, 353);
			this->Whiskey->Name = L"Whiskey";
			this->Whiskey->Size = System::Drawing::Size(83, 21);
			this->Whiskey->TabIndex = 0;
			this->Whiskey->Text = L"Whiskey";
			this->Whiskey->UseVisualStyleBackColor = true;
			// 
			// Limonade
			// 
			this->Limonade->AutoSize = true;
			this->Limonade->Location = System::Drawing::Point(34, 236);
			this->Limonade->Name = L"Limonade";
			this->Limonade->Size = System::Drawing::Size(97, 21);
			this->Limonade->TabIndex = 0;
			this->Limonade->Text = L"Lemonade";
			this->Limonade->UseVisualStyleBackColor = true;
			// 
			// Champagne
			// 
			this->Champagne->AutoSize = true;
			this->Champagne->Location = System::Drawing::Point(34, 392);
			this->Champagne->Name = L"Champagne";
			this->Champagne->Size = System::Drawing::Size(106, 21);
			this->Champagne->TabIndex = 0;
			this->Champagne->Text = L"Champagne";
			this->Champagne->UseVisualStyleBackColor = true;
			// 
			// Fanta
			// 
			this->Fanta->AutoSize = true;
			this->Fanta->Location = System::Drawing::Point(34, 81);
			this->Fanta->Name = L"Fanta";
			this->Fanta->Size = System::Drawing::Size(66, 21);
			this->Fanta->TabIndex = 0;
			this->Fanta->Text = L"Fanta";
			this->Fanta->UseVisualStyleBackColor = true;
			// 
			// Beer
			// 
			this->Beer->AutoSize = true;
			this->Beer->Location = System::Drawing::Point(34, 275);
			this->Beer->Name = L"Beer";
			this->Beer->Size = System::Drawing::Size(60, 21);
			this->Beer->TabIndex = 0;
			this->Beer->Text = L"Beer";
			this->Beer->UseVisualStyleBackColor = true;
			// 
			// SparklingWater
			// 
			this->SparklingWater->AutoSize = true;
			this->SparklingWater->Location = System::Drawing::Point(34, 120);
			this->SparklingWater->Name = L"SparklingWater";
			this->SparklingWater->Size = System::Drawing::Size(131, 21);
			this->SparklingWater->TabIndex = 0;
			this->SparklingWater->Text = L"Sparkling Water";
			this->SparklingWater->UseVisualStyleBackColor = true;
			// 
			// FreshJuice
			// 
			this->FreshJuice->AutoSize = true;
			this->FreshJuice->Location = System::Drawing::Point(34, 197);
			this->FreshJuice->Name = L"FreshJuice";
			this->FreshJuice->Size = System::Drawing::Size(103, 21);
			this->FreshJuice->TabIndex = 0;
			this->FreshJuice->Text = L"Fresh Juice";
			this->FreshJuice->UseVisualStyleBackColor = true;
			// 
			// CocaCola
			// 
			this->CocaCola->AutoSize = true;
			this->CocaCola->Location = System::Drawing::Point(34, 42);
			this->CocaCola->Name = L"CocaCola";
			this->CocaCola->Size = System::Drawing::Size(94, 21);
			this->CocaCola->TabIndex = 0;
			this->CocaCola->Text = L"Coca Cola";
			this->CocaCola->UseVisualStyleBackColor = true;
			// 
			// OkBtn
			// 
			this->OkBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->OkBtn->Location = System::Drawing::Point(871, 577);
			this->OkBtn->Name = L"OkBtn";
			this->OkBtn->Size = System::Drawing::Size(75, 28);
			this->OkBtn->TabIndex = 3;
			this->OkBtn->Text = L"Ok";
			this->OkBtn->UseVisualStyleBackColor = true;
			this->OkBtn->Click += gcnew System::EventHandler(this, &RoomService::OkBtn_Click);
			// 
			// ClientID
			// 
			this->ClientID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ClientID->Location = System::Drawing::Point(747, 580);
			this->ClientID->Name = L"ClientID";
			this->ClientID->Size = System::Drawing::Size(100, 15);
			this->ClientID->TabIndex = 4;
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->numericUpDown25);
			this->groupBox3->Controls->Add(this->numericUpDown28);
			this->groupBox3->Controls->Add(this->numericUpDown31);
			this->groupBox3->Controls->Add(this->numericUpDown32);
			this->groupBox3->Controls->Add(this->numericUpDown33);
			this->groupBox3->Controls->Add(this->VeggiePizza);
			this->groupBox3->Controls->Add(this->VeggieBurger);
			this->groupBox3->Controls->Add(this->MacNCheese);
			this->groupBox3->Controls->Add(this->VeggieSalad);
			this->groupBox3->Controls->Add(this->CheeseSandwich);
			this->groupBox3->Location = System::Drawing::Point(371, 47);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(323, 238);
			this->groupBox3->TabIndex = 2;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Vegetarian Food";
			// 
			// numericUpDown25
			// 
			this->numericUpDown25->Location = System::Drawing::Point(209, 159);
			this->numericUpDown25->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown25->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown25->Name = L"numericUpDown25";
			this->numericUpDown25->Size = System::Drawing::Size(67, 22);
			this->numericUpDown25->TabIndex = 1;
			this->numericUpDown25->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown28
			// 
			this->numericUpDown28->Location = System::Drawing::Point(209, 81);
			this->numericUpDown28->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown28->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown28->Name = L"numericUpDown28";
			this->numericUpDown28->Size = System::Drawing::Size(67, 22);
			this->numericUpDown28->TabIndex = 1;
			this->numericUpDown28->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown31
			// 
			this->numericUpDown31->Location = System::Drawing::Point(209, 120);
			this->numericUpDown31->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown31->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown31->Name = L"numericUpDown31";
			this->numericUpDown31->Size = System::Drawing::Size(67, 22);
			this->numericUpDown31->TabIndex = 1;
			this->numericUpDown31->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown32
			// 
			this->numericUpDown32->Location = System::Drawing::Point(209, 197);
			this->numericUpDown32->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown32->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown32->Name = L"numericUpDown32";
			this->numericUpDown32->Size = System::Drawing::Size(67, 22);
			this->numericUpDown32->TabIndex = 1;
			this->numericUpDown32->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown33
			// 
			this->numericUpDown33->Location = System::Drawing::Point(209, 42);
			this->numericUpDown33->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown33->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown33->Name = L"numericUpDown33";
			this->numericUpDown33->Size = System::Drawing::Size(67, 22);
			this->numericUpDown33->TabIndex = 1;
			this->numericUpDown33->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// VeggiePizza
			// 
			this->VeggiePizza->AutoSize = true;
			this->VeggiePizza->Location = System::Drawing::Point(34, 159);
			this->VeggiePizza->Name = L"VeggiePizza";
			this->VeggiePizza->Size = System::Drawing::Size(112, 21);
			this->VeggiePizza->TabIndex = 0;
			this->VeggiePizza->Text = L"Veggie Pizza";
			this->VeggiePizza->UseVisualStyleBackColor = true;
			// 
			// VeggieBurger
			// 
			this->VeggieBurger->AutoSize = true;
			this->VeggieBurger->Location = System::Drawing::Point(34, 81);
			this->VeggieBurger->Name = L"VeggieBurger";
			this->VeggieBurger->Size = System::Drawing::Size(121, 21);
			this->VeggieBurger->TabIndex = 0;
			this->VeggieBurger->Text = L"Veggie Burger";
			this->VeggieBurger->UseVisualStyleBackColor = true;
			// 
			// MacNCheese
			// 
			this->MacNCheese->AutoSize = true;
			this->MacNCheese->Location = System::Drawing::Point(34, 120);
			this->MacNCheese->Name = L"MacNCheese";
			this->MacNCheese->Size = System::Drawing::Size(122, 21);
			this->MacNCheese->TabIndex = 0;
			this->MacNCheese->Text = L"Mac N Cheese";
			this->MacNCheese->UseVisualStyleBackColor = true;
			// 
			// VeggieSalad
			// 
			this->VeggieSalad->AutoSize = true;
			this->VeggieSalad->Location = System::Drawing::Point(34, 197);
			this->VeggieSalad->Name = L"VeggieSalad";
			this->VeggieSalad->Size = System::Drawing::Size(147, 21);
			this->VeggieSalad->TabIndex = 0;
			this->VeggieSalad->Text = L"Veggie Chilli Salad";
			this->VeggieSalad->UseVisualStyleBackColor = true;
			// 
			// CheeseSandwich
			// 
			this->CheeseSandwich->AutoSize = true;
			this->CheeseSandwich->Location = System::Drawing::Point(34, 42);
			this->CheeseSandwich->Name = L"CheeseSandwich";
			this->CheeseSandwich->Size = System::Drawing::Size(142, 21);
			this->CheeseSandwich->TabIndex = 0;
			this->CheeseSandwich->Text = L"Cheese Sandwich";
			this->CheeseSandwich->UseVisualStyleBackColor = true;
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->numericUpDown23);
			this->groupBox4->Controls->Add(this->numericUpDown24);
			this->groupBox4->Controls->Add(this->numericUpDown26);
			this->groupBox4->Controls->Add(this->numericUpDown29);
			this->groupBox4->Controls->Add(this->Pastries);
			this->groupBox4->Controls->Add(this->CheeseCake);
			this->groupBox4->Controls->Add(this->Pudding);
			this->groupBox4->Controls->Add(this->Brownie);
			this->groupBox4->Location = System::Drawing::Point(371, 308);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(323, 220);
			this->groupBox4->TabIndex = 2;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L"Dessert";
			// 
			// numericUpDown23
			// 
			this->numericUpDown23->Location = System::Drawing::Point(209, 159);
			this->numericUpDown23->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown23->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown23->Name = L"numericUpDown23";
			this->numericUpDown23->Size = System::Drawing::Size(67, 22);
			this->numericUpDown23->TabIndex = 1;
			this->numericUpDown23->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown24
			// 
			this->numericUpDown24->Location = System::Drawing::Point(209, 81);
			this->numericUpDown24->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown24->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown24->Name = L"numericUpDown24";
			this->numericUpDown24->Size = System::Drawing::Size(67, 22);
			this->numericUpDown24->TabIndex = 1;
			this->numericUpDown24->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown26
			// 
			this->numericUpDown26->Location = System::Drawing::Point(209, 120);
			this->numericUpDown26->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown26->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown26->Name = L"numericUpDown26";
			this->numericUpDown26->Size = System::Drawing::Size(67, 22);
			this->numericUpDown26->TabIndex = 1;
			this->numericUpDown26->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// numericUpDown29
			// 
			this->numericUpDown29->Location = System::Drawing::Point(209, 42);
			this->numericUpDown29->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown29->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown29->Name = L"numericUpDown29";
			this->numericUpDown29->Size = System::Drawing::Size(67, 22);
			this->numericUpDown29->TabIndex = 1;
			this->numericUpDown29->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// Pastries
			// 
			this->Pastries->AutoSize = true;
			this->Pastries->Location = System::Drawing::Point(34, 159);
			this->Pastries->Name = L"Pastries";
			this->Pastries->Size = System::Drawing::Size(81, 21);
			this->Pastries->TabIndex = 0;
			this->Pastries->Text = L"Pastries";
			this->Pastries->UseVisualStyleBackColor = true;
			// 
			// CheeseCake
			// 
			this->CheeseCake->AutoSize = true;
			this->CheeseCake->Location = System::Drawing::Point(34, 81);
			this->CheeseCake->Name = L"CheeseCake";
			this->CheeseCake->Size = System::Drawing::Size(114, 21);
			this->CheeseCake->TabIndex = 0;
			this->CheeseCake->Text = L"Cheese Cake";
			this->CheeseCake->UseVisualStyleBackColor = true;
			// 
			// Pudding
			// 
			this->Pudding->AutoSize = true;
			this->Pudding->Location = System::Drawing::Point(34, 120);
			this->Pudding->Name = L"Pudding";
			this->Pudding->Size = System::Drawing::Size(82, 21);
			this->Pudding->TabIndex = 0;
			this->Pudding->Text = L"Pudding";
			this->Pudding->UseVisualStyleBackColor = true;
			// 
			// Brownie
			// 
			this->Brownie->AutoSize = true;
			this->Brownie->Location = System::Drawing::Point(34, 42);
			this->Brownie->Name = L"Brownie";
			this->Brownie->Size = System::Drawing::Size(80, 21);
			this->Brownie->TabIndex = 0;
			this->Brownie->Text = L"Brownie";
			this->Brownie->UseVisualStyleBackColor = true;
			// 
			// ClientID1
			// 
			this->ClientID1->AutoSize = true;
			this->ClientID1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ClientID1->Location = System::Drawing::Point(750, 557);
			this->ClientID1->Name = L"ClientID1";
			this->ClientID1->Size = System::Drawing::Size(66, 16);
			this->ClientID1->TabIndex = 5;
			this->ClientID1->Text = L"Client ID";
			// 
			// Delete
			// 
			this->Delete->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Delete->Location = System::Drawing::Point(963, 577);
			this->Delete->Name = L"Delete";
			this->Delete->Size = System::Drawing::Size(75, 28);
			this->Delete->TabIndex = 13;
			this->Delete->Text = L"Delete";
			this->Delete->UseVisualStyleBackColor = true;
			this->Delete->Click += gcnew System::EventHandler(this, &RoomService::Delete_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->pictureBox1->Location = System::Drawing::Point(1087, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(377, 627);
			this->pictureBox1->TabIndex = 14;
			this->pictureBox1->TabStop = false;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel1->Location = System::Drawing::Point(747, 599);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(99, 3);
			this->panel1->TabIndex = 15;
			// 
			// RoomService
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1464, 627);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->Delete);
			this->Controls->Add(this->ClientID1);
			this->Controls->Add(this->ClientID);
			this->Controls->Add(this->OkBtn);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox1);
			this->Name = L"RoomService";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"RoomService";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown5))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown6))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown7))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown8))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown9))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown10))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown11))->EndInit();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown12))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown13))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown14))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown15))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown16))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown17))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown18))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown19))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown20))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown21))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown22))->EndInit();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown25))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown28))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown31))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown32))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown33))->EndInit();
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown23))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown24))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown26))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown29))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion


		private: System::Void OkBtn_Click(System::Object^ sender, System::EventArgs^ e) {

			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			int clientid = Int32::Parse(ClientID->Text);

			if (ChickenBurger->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES ("+clientid+", 'Chicken Burger', "+numericUpDown1->Value+")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (AlfredoPasta->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Alfredo Pasta', " + numericUpDown2->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (LambLasagna->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Lamb Lasagna', " + numericUpDown3->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (SeaFoodPlater->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Sea Food Plater', " + numericUpDown4->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (ChickenSalad->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Chicken Salad', " + numericUpDown5->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (BeefSandwich->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Beef Sandwich', " + numericUpDown7->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (SeafoodPaella->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Seafood Paella', " + numericUpDown6->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (CrabSoup->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'She-Crab Soup', " + numericUpDown8->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (BeefSteak->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Beef Steak', " + numericUpDown10->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Sushi->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Sushi', " + numericUpDown9->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (TandooriChicken->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Tandoori Chicken', " + numericUpDown11->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}




























			if (CheeseSandwich->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Cheese Sandwich', " + numericUpDown33->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (VeggieBurger->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Veggie Burger', " + numericUpDown28->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (MacNCheese->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'MacNCheese', " + numericUpDown31->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (VeggiePizza->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Veggie Pizza', " + numericUpDown25->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (VeggieSalad->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'VeggieSalad', " + numericUpDown32->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}







































			if (Brownie->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Brownie', " + numericUpDown29->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (CheeseCake->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Cheese Cake', " + numericUpDown24->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Pudding->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Pudding', " + numericUpDown26->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Pastries->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Pastries', " + numericUpDown23->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

























































			if (CocaCola->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Coca Cola', " + numericUpDown22->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Fanta->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Fanta', " + numericUpDown17->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (SparklingWater->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Sparkling Water', " + numericUpDown20->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Sprite->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Sprite', " + numericUpDown14->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Limonade->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Limonade', " + numericUpDown16->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Beer->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Beer', " + numericUpDown19->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Wine->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Wine', " + numericUpDown13->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}


			if (FreshJuice->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Fresh Juice', " + numericUpDown21->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Whiskey->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Whiskey', " + numericUpDown15->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Mojito->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO roomservice_info (client_id, food, quantity) VALUES (" + clientid + ", 'Mojito', " + numericUpDown12->Value + ")", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}




			RoomService::Close();
		}

		private: System::Void Delete_Click(System::Object^ sender, System::EventArgs^ e) {
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			int clientid = Int32::Parse(ClientID->Text);
			MySqlCommand^ cmd = gcnew MySqlCommand("delete from roomservice_info where client_id=" + clientid + " ", con);

			con->Open();
			MySqlDataReader^ dr = cmd->ExecuteReader();
			MessageBox::Show("Deleted");
			con->Close();
		}
};
}
