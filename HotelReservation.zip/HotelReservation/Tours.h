#pragma once

namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for Tours
	/// </summary>
	public ref class Tours : public System::Windows::Forms::Form
	{
	public:
		Tours(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Tours()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^ OffRoadBiking;
	protected:

	private: System::Windows::Forms::CheckBox^ NaturalReserves;
	protected:

	private: System::Windows::Forms::CheckBox^ ZooVisit;

	private: System::Windows::Forms::CheckBox^ MountainHiking;

	private: System::Windows::Forms::CheckBox^ Trail;

	private: System::Windows::Forms::DateTimePicker^ dateTimePicker1;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown1;
	private: System::Windows::Forms::TextBox^ ClientID;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Button^ OkBtn;
	private: System::Windows::Forms::Button^ Delete;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Panel^ panel1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Tours::typeid));
			this->OffRoadBiking = (gcnew System::Windows::Forms::CheckBox());
			this->NaturalReserves = (gcnew System::Windows::Forms::CheckBox());
			this->ZooVisit = (gcnew System::Windows::Forms::CheckBox());
			this->MountainHiking = (gcnew System::Windows::Forms::CheckBox());
			this->Trail = (gcnew System::Windows::Forms::CheckBox());
			this->dateTimePicker1 = (gcnew System::Windows::Forms::DateTimePicker());
			this->numericUpDown1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->ClientID = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->OkBtn = (gcnew System::Windows::Forms::Button());
			this->Delete = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// OffRoadBiking
			// 
			this->OffRoadBiking->AutoSize = true;
			this->OffRoadBiking->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->OffRoadBiking->Location = System::Drawing::Point(44, 193);
			this->OffRoadBiking->Name = L"OffRoadBiking";
			this->OffRoadBiking->Size = System::Drawing::Size(150, 24);
			this->OffRoadBiking->TabIndex = 6;
			this->OffRoadBiking->Text = L"Off Road Biking";
			this->OffRoadBiking->UseVisualStyleBackColor = true;
			// 
			// NaturalReserves
			// 
			this->NaturalReserves->AutoSize = true;
			this->NaturalReserves->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->NaturalReserves->Location = System::Drawing::Point(44, 163);
			this->NaturalReserves->Name = L"NaturalReserves";
			this->NaturalReserves->Size = System::Drawing::Size(153, 24);
			this->NaturalReserves->TabIndex = 7;
			this->NaturalReserves->Text = L"Natural reserves";
			this->NaturalReserves->UseVisualStyleBackColor = true;
			// 
			// ZooVisit
			// 
			this->ZooVisit->AutoSize = true;
			this->ZooVisit->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ZooVisit->Location = System::Drawing::Point(44, 133);
			this->ZooVisit->Name = L"ZooVisit";
			this->ZooVisit->Size = System::Drawing::Size(93, 24);
			this->ZooVisit->TabIndex = 8;
			this->ZooVisit->Text = L"Zoo visit";
			this->ZooVisit->UseVisualStyleBackColor = true;
			// 
			// MountainHiking
			// 
			this->MountainHiking->AutoSize = true;
			this->MountainHiking->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->MountainHiking->Location = System::Drawing::Point(44, 103);
			this->MountainHiking->Name = L"MountainHiking";
			this->MountainHiking->Size = System::Drawing::Size(152, 24);
			this->MountainHiking->TabIndex = 9;
			this->MountainHiking->Text = L"Mountain Hiking";
			this->MountainHiking->UseVisualStyleBackColor = true;
			// 
			// Trail
			// 
			this->Trail->AutoSize = true;
			this->Trail->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Trail->Location = System::Drawing::Point(44, 73);
			this->Trail->Name = L"Trail";
			this->Trail->Size = System::Drawing::Size(64, 24);
			this->Trail->TabIndex = 10;
			this->Trail->Text = L"Trail";
			this->Trail->UseVisualStyleBackColor = true;
			// 
			// dateTimePicker1
			// 
			this->dateTimePicker1->Location = System::Drawing::Point(44, 280);
			this->dateTimePicker1->Name = L"dateTimePicker1";
			this->dateTimePicker1->Size = System::Drawing::Size(256, 22);
			this->dateTimePicker1->TabIndex = 11;
			// 
			// numericUpDown1
			// 
			this->numericUpDown1->Location = System::Drawing::Point(374, 75);
			this->numericUpDown1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 200, 0, 0, 0 });
			this->numericUpDown1->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->numericUpDown1->Name = L"numericUpDown1";
			this->numericUpDown1->Size = System::Drawing::Size(62, 22);
			this->numericUpDown1->TabIndex = 12;
			this->numericUpDown1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			// 
			// ClientID
			// 
			this->ClientID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ClientID->Location = System::Drawing::Point(241, 540);
			this->ClientID->Name = L"ClientID";
			this->ClientID->Size = System::Drawing::Size(100, 15);
			this->ClientID->TabIndex = 15;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(244, 520);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(62, 16);
			this->label4->TabIndex = 14;
			this->label4->Text = L"ClientID";
			// 
			// OkBtn
			// 
			this->OkBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->OkBtn->Location = System::Drawing::Point(363, 537);
			this->OkBtn->Name = L"OkBtn";
			this->OkBtn->Size = System::Drawing::Size(75, 25);
			this->OkBtn->TabIndex = 13;
			this->OkBtn->Text = L"Ok";
			this->OkBtn->UseVisualStyleBackColor = true;
			this->OkBtn->Click += gcnew System::EventHandler(this, &Tours::OkBtn_Click);
			// 
			// Delete
			// 
			this->Delete->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Delete->Location = System::Drawing::Point(445, 537);
			this->Delete->Name = L"Delete";
			this->Delete->Size = System::Drawing::Size(75, 25);
			this->Delete->TabIndex = 13;
			this->Delete->Text = L"Delete";
			this->Delete->UseVisualStyleBackColor = true;
			this->Delete->Click += gcnew System::EventHandler(this, &Tours::Delete_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(28, 39);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(61, 22);
			this->label1->TabIndex = 14;
			this->label1->Text = L"Tours";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(41, 260);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(40, 16);
			this->label2->TabIndex = 14;
			this->label2->Text = L"Date";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(361, 44);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(140, 16);
			this->label3->TabIndex = 14;
			this->label3->Text = L"Number of persons";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->pictureBox1->Location = System::Drawing::Point(556, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(401, 614);
			this->pictureBox1->TabIndex = 16;
			this->pictureBox1->TabStop = false;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel1->Location = System::Drawing::Point(241, 559);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(99, 3);
			this->panel1->TabIndex = 17;
			// 
			// Tours
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(957, 614);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->ClientID);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->Delete);
			this->Controls->Add(this->OkBtn);
			this->Controls->Add(this->numericUpDown1);
			this->Controls->Add(this->dateTimePicker1);
			this->Controls->Add(this->OffRoadBiking);
			this->Controls->Add(this->NaturalReserves);
			this->Controls->Add(this->ZooVisit);
			this->Controls->Add(this->MountainHiking);
			this->Controls->Add(this->Trail);
			this->Name = L"Tours";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Tours";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void OkBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
		MySqlConnection^ con = gcnew MySqlConnection(constr);

		int clientid = Int32::Parse(ClientID->Text);

		DateTime datePicker = dateTimePicker1->Value;
		int year = datePicker.Year;
		int month = datePicker.Month;
		int day = datePicker.Day;
		String^ date = "  " + year + "-" + month + "-" + day + "  ";

		if (Trail->Checked)
		{
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO tours_info (client_id, type, num_of_persons, date) VALUES (" + clientid + ", 'Trail', " + numericUpDown1->Value + ", '" + date + "')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		if (MountainHiking->Checked)
		{
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO tours_info (client_id, type, num_of_persons, date) VALUES (" + clientid + ", 'Mountain Hiking', " + numericUpDown1->Value + ", '" + date + "')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		if (ZooVisit->Checked)
		{
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO tours_info (client_id, type, num_of_persons, date) VALUES (" + clientid + ", 'Zoo Visit', " + numericUpDown1->Value + ", '" + date + "')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		if (NaturalReserves->Checked)
		{
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO tours_info (client_id, type, num_of_persons, date) VALUES (" + clientid + ", 'Natural Reserves', " + numericUpDown1->Value + ", '" + date + "')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		if (OffRoadBiking->Checked)
		{
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO tours_info (client_id, type, num_of_persons, date) VALUES (" + clientid + ", 'Off Road Biking', " + numericUpDown1->Value + ", '" + date + "')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}
	}


	private: System::Void Delete_Click(System::Object^ sender, System::EventArgs^ e) {

		String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
		MySqlConnection^ con = gcnew MySqlConnection(constr);

		int clientid = Int32::Parse(ClientID->Text);
		MySqlCommand^ cmd = gcnew MySqlCommand("delete from tours_info where client_id=" + clientid + " ", con);

		con->Open();
		MySqlDataReader^ dr = cmd->ExecuteReader();
		MessageBox::Show("Deleted");
		con->Close();
	}
};
}
