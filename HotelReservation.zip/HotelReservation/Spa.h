#pragma once

namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for Spa
	/// </summary>
	public ref class Spa : public System::Windows::Forms::Form
	{
	public:
		Spa(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Spa()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ OkBtn;
	protected:

	private: System::Windows::Forms::CheckBox^ CoupleMassage;
	protected:



	private: System::Windows::Forms::CheckBox^ FullBodyMassage;
	private: System::Windows::Forms::CheckBox^ Sona;
	private: System::Windows::Forms::CheckBox^ Facial;
	private: System::Windows::Forms::CheckBox^ Manicure;
	private: System::Windows::Forms::CheckBox^ Pedicure;
	private: System::Windows::Forms::TextBox^ ClientID;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ Delete;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker1;







	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Spa::typeid));
			this->OkBtn = (gcnew System::Windows::Forms::Button());
			this->CoupleMassage = (gcnew System::Windows::Forms::CheckBox());
			this->FullBodyMassage = (gcnew System::Windows::Forms::CheckBox());
			this->Sona = (gcnew System::Windows::Forms::CheckBox());
			this->Facial = (gcnew System::Windows::Forms::CheckBox());
			this->Manicure = (gcnew System::Windows::Forms::CheckBox());
			this->Pedicure = (gcnew System::Windows::Forms::CheckBox());
			this->ClientID = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->Delete = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->dateTimePicker1 = (gcnew System::Windows::Forms::DateTimePicker());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// OkBtn
			// 
			this->OkBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->OkBtn->Location = System::Drawing::Point(344, 502);
			this->OkBtn->Name = L"OkBtn";
			this->OkBtn->Size = System::Drawing::Size(75, 28);
			this->OkBtn->TabIndex = 7;
			this->OkBtn->Text = L"Ok";
			this->OkBtn->UseVisualStyleBackColor = true;
			this->OkBtn->Click += gcnew System::EventHandler(this, &Spa::OkBtn_Click);
			// 
			// CoupleMassage
			// 
			this->CoupleMassage->AutoSize = true;
			this->CoupleMassage->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->CoupleMassage->Location = System::Drawing::Point(49, 121);
			this->CoupleMassage->Name = L"CoupleMassage";
			this->CoupleMassage->Size = System::Drawing::Size(157, 24);
			this->CoupleMassage->TabIndex = 3;
			this->CoupleMassage->Text = L"Couple massage";
			this->CoupleMassage->UseVisualStyleBackColor = true;
			// 
			// FullBodyMassage
			// 
			this->FullBodyMassage->AutoSize = true;
			this->FullBodyMassage->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->FullBodyMassage->Location = System::Drawing::Point(49, 84);
			this->FullBodyMassage->Name = L"FullBodyMassage";
			this->FullBodyMassage->Size = System::Drawing::Size(171, 24);
			this->FullBodyMassage->TabIndex = 4;
			this->FullBodyMassage->Text = L"Full body massage";
			this->FullBodyMassage->UseVisualStyleBackColor = true;
			// 
			// Sona
			// 
			this->Sona->AutoSize = true;
			this->Sona->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Sona->Location = System::Drawing::Point(49, 158);
			this->Sona->Name = L"Sona";
			this->Sona->Size = System::Drawing::Size(78, 24);
			this->Sona->TabIndex = 3;
			this->Sona->Text = L"Sauna";
			this->Sona->UseVisualStyleBackColor = true;
			// 
			// Facial
			// 
			this->Facial->AutoSize = true;
			this->Facial->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Facial->Location = System::Drawing::Point(49, 195);
			this->Facial->Name = L"Facial";
			this->Facial->Size = System::Drawing::Size(119, 24);
			this->Facial->TabIndex = 3;
			this->Facial->Text = L"Gold Facial";
			this->Facial->UseVisualStyleBackColor = true;
			// 
			// Manicure
			// 
			this->Manicure->AutoSize = true;
			this->Manicure->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Manicure->Location = System::Drawing::Point(49, 232);
			this->Manicure->Name = L"Manicure";
			this->Manicure->Size = System::Drawing::Size(100, 24);
			this->Manicure->TabIndex = 3;
			this->Manicure->Text = L"Manicure";
			this->Manicure->UseVisualStyleBackColor = true;
			// 
			// Pedicure
			// 
			this->Pedicure->AutoSize = true;
			this->Pedicure->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Pedicure->Location = System::Drawing::Point(49, 269);
			this->Pedicure->Name = L"Pedicure";
			this->Pedicure->Size = System::Drawing::Size(95, 24);
			this->Pedicure->TabIndex = 3;
			this->Pedicure->Text = L"Pedicure";
			this->Pedicure->UseVisualStyleBackColor = true;
			// 
			// ClientID
			// 
			this->ClientID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ClientID->Location = System::Drawing::Point(210, 502);
			this->ClientID->Name = L"ClientID";
			this->ClientID->Size = System::Drawing::Size(100, 15);
			this->ClientID->TabIndex = 8;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(210, 476);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(66, 16);
			this->label1->TabIndex = 9;
			this->label1->Text = L"Client ID";
			// 
			// Delete
			// 
			this->Delete->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Delete->Location = System::Drawing::Point(434, 502);
			this->Delete->Name = L"Delete";
			this->Delete->Size = System::Drawing::Size(75, 28);
			this->Delete->TabIndex = 12;
			this->Delete->Text = L"Delete";
			this->Delete->UseVisualStyleBackColor = true;
			this->Delete->Click += gcnew System::EventHandler(this, &Spa::Delete_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(29, 44);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(123, 22);
			this->label2->TabIndex = 9;
			this->label2->Text = L"Spa services";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->pictureBox1->Location = System::Drawing::Point(554, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(350, 558);
			this->pictureBox1->TabIndex = 13;
			this->pictureBox1->TabStop = false;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel1->Location = System::Drawing::Point(211, 521);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(99, 3);
			this->panel1->TabIndex = 14;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(30, 325);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(40, 16);
			this->label3->TabIndex = 16;
			this->label3->Text = L"Date";
			// 
			// dateTimePicker1
			// 
			this->dateTimePicker1->Location = System::Drawing::Point(49, 355);
			this->dateTimePicker1->Name = L"dateTimePicker1";
			this->dateTimePicker1->Size = System::Drawing::Size(256, 22);
			this->dateTimePicker1->TabIndex = 15;
			// 
			// Spa
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(904, 558);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->dateTimePicker1);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->Delete);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->ClientID);
			this->Controls->Add(this->OkBtn);
			this->Controls->Add(this->Pedicure);
			this->Controls->Add(this->Manicure);
			this->Controls->Add(this->Facial);
			this->Controls->Add(this->Sona);
			this->Controls->Add(this->CoupleMassage);
			this->Controls->Add(this->FullBodyMassage);
			this->Name = L"Spa";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Spa";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		private: System::Void OkBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			DateTime dateTime = dateTimePicker1->Value;
			int year = dateTime.Year;
			int month = dateTime.Month;
			int day = dateTime.Day;
			String^ date = "  " + year + "-" + month + "-" + day + "  ";

			int clientid = Int32::Parse(ClientID->Text);

			if (FullBodyMassage->Checked)
			{
				try
				{

					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO spa_info (treatment, client_id, date) VALUES ('Full_Body_Massage', "+clientid+", '" + date + "')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (CoupleMassage->Checked)
			{
				try
				{

					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO spa_info (treatment, client_id, date) VALUES ('Couple_Massage', " + clientid + ", '" + date + "')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Sona->Checked)
			{
				try
				{

					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO spa_info (treatment, client_id, date) VALUES ('Sona', " + clientid + ", '" + date + "')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Facial->Checked)
			{
				try
				{

					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO spa_info (treatment, client_id, date) VALUES ('Facial', " + clientid + ", '" + date + "')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Manicure->Checked)
			{
				try
				{

					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO spa_info (treatment, client_id, date) VALUES ('Manicure', " + clientid + ", '" + date + "')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Pedicure->Checked)
			{
				try
				{

					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO spa_info (treatment, client_id, date) VALUES ('Pedicure', " + clientid + ", '" + date + "')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			Spa::Close();
		}

		private: System::Void Delete_Click(System::Object^ sender, System::EventArgs^ e) {
			try
			{
				String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
				MySqlConnection^ con = gcnew MySqlConnection(constr);

				int clientid = Int32::Parse(ClientID->Text);
				MySqlCommand^ cmd = gcnew MySqlCommand("delete from spa_info where client_id=" + clientid + " ", con);

				con->Open();
				MySqlDataReader^ dr = cmd->ExecuteReader();
				MessageBox::Show("Deleted");
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}
};
}
