#pragma once
#include "Room.h"
#include "Spa.h"
#include "Transport.h"
#include "Lounge.h"
#include "Cleaning.h"
#include "Pool.h"
#include "Flight.h"
#include "Parking.h"
#include "Activities.h"
#include "Entertainment.h"
#include "KidsCorner.h"
#include "Health.h"
#include "Sport.h"
#include "RoomService.h"
#include "Restaurant.h"
#include "Tours.h"


namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for HotelReservation
	/// </summary>
	public ref class HotelReservation : public System::Windows::Forms::Form
	{
	public:
		HotelReservation(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~HotelReservation()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ ActivitiesBtn;
	private: System::Windows::Forms::Button^ HealthBtn;
	protected:

	protected:


	private: System::Windows::Forms::Button^ ParkingBtn;
	private: System::Windows::Forms::Button^ RestaurantBtn;
	protected:




	private: System::Windows::Forms::Button^ FlightBtn;
	private: System::Windows::Forms::Button^ KidcornerBtn;


	private: System::Windows::Forms::Button^ EntertainmentBtn;
	private: System::Windows::Forms::Button^ SportBtn;




	private: System::Windows::Forms::Button^ PoolBtn;
	private: System::Windows::Forms::Button^ ToursBtn;




	private: System::Windows::Forms::Button^ CleaningBtn;


	private: System::Windows::Forms::Button^ LoungeBtn;

	private: System::Windows::Forms::Button^ TransportBtn;
	private: System::Windows::Forms::Button^ RoomServiceBtn;




	private: System::Windows::Forms::Button^ SpaBtn;

	private: System::Windows::Forms::Button^ RoomBtn;

	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ Persons;

	private: System::Windows::Forms::TextBox^ Mobile;
	private: System::Windows::Forms::TextBox^ Email;


	private: System::Windows::Forms::TextBox^ LastName;

	private: System::Windows::Forms::TextBox^ FirstName;
	private: System::Windows::Forms::Button^ AddClientBtn;
	private: System::Windows::Forms::Button^ SearchClient;
	private: System::Windows::Forms::Label^ ClientIDLabel;
	private: System::Windows::Forms::Button^ DeleteClient;
	private: System::Windows::Forms::Button^ UpdateBtn;
	private: System::Windows::Forms::Label^ ID1;
	private: System::Windows::Forms::TextBox^ ID;
	private: System::Windows::Forms::Panel^ panel6;
	private: System::Windows::Forms::Panel^ panel5;
	private: System::Windows::Forms::Panel^ panel4;
	private: System::Windows::Forms::Panel^ panel7;
	private: System::Windows::Forms::Panel^ panel3;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Button^ CloseBtn;
	private: System::Windows::Forms::Panel^ panel8;





	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(HotelReservation::typeid));
			this->ActivitiesBtn = (gcnew System::Windows::Forms::Button());
			this->HealthBtn = (gcnew System::Windows::Forms::Button());
			this->ParkingBtn = (gcnew System::Windows::Forms::Button());
			this->RestaurantBtn = (gcnew System::Windows::Forms::Button());
			this->FlightBtn = (gcnew System::Windows::Forms::Button());
			this->KidcornerBtn = (gcnew System::Windows::Forms::Button());
			this->EntertainmentBtn = (gcnew System::Windows::Forms::Button());
			this->SportBtn = (gcnew System::Windows::Forms::Button());
			this->PoolBtn = (gcnew System::Windows::Forms::Button());
			this->ToursBtn = (gcnew System::Windows::Forms::Button());
			this->CleaningBtn = (gcnew System::Windows::Forms::Button());
			this->LoungeBtn = (gcnew System::Windows::Forms::Button());
			this->TransportBtn = (gcnew System::Windows::Forms::Button());
			this->RoomServiceBtn = (gcnew System::Windows::Forms::Button());
			this->SpaBtn = (gcnew System::Windows::Forms::Button());
			this->RoomBtn = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->panel6 = (gcnew System::Windows::Forms::Panel());
			this->panel5 = (gcnew System::Windows::Forms::Panel());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->panel7 = (gcnew System::Windows::Forms::Panel());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->ClientIDLabel = (gcnew System::Windows::Forms::Label());
			this->UpdateBtn = (gcnew System::Windows::Forms::Button());
			this->DeleteClient = (gcnew System::Windows::Forms::Button());
			this->SearchClient = (gcnew System::Windows::Forms::Button());
			this->AddClientBtn = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->ID1 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->Persons = (gcnew System::Windows::Forms::TextBox());
			this->ID = (gcnew System::Windows::Forms::TextBox());
			this->Mobile = (gcnew System::Windows::Forms::TextBox());
			this->Email = (gcnew System::Windows::Forms::TextBox());
			this->LastName = (gcnew System::Windows::Forms::TextBox());
			this->FirstName = (gcnew System::Windows::Forms::TextBox());
			this->CloseBtn = (gcnew System::Windows::Forms::Button());
			this->panel8 = (gcnew System::Windows::Forms::Panel());
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// ActivitiesBtn
			// 
			this->ActivitiesBtn->BackColor = System::Drawing::Color::White;
			this->ActivitiesBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->ActivitiesBtn->FlatAppearance->BorderSize = 3;
			this->ActivitiesBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->ActivitiesBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->ActivitiesBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->ActivitiesBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ActivitiesBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->ActivitiesBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"ActivitiesBtn.Image")));
			this->ActivitiesBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->ActivitiesBtn->Location = System::Drawing::Point(418, 612);
			this->ActivitiesBtn->Name = L"ActivitiesBtn";
			this->ActivitiesBtn->Padding = System::Windows::Forms::Padding(10, 15, 10, 10);
			this->ActivitiesBtn->Size = System::Drawing::Size(242, 174);
			this->ActivitiesBtn->TabIndex = 18;
			this->ActivitiesBtn->Text = L"Activities";
			this->ActivitiesBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->ActivitiesBtn->UseVisualStyleBackColor = false;
			this->ActivitiesBtn->Click += gcnew System::EventHandler(this, &HotelReservation::ActivitiesBtn_Click);
			// 
			// HealthBtn
			// 
			this->HealthBtn->BackColor = System::Drawing::Color::White;
			this->HealthBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->HealthBtn->FlatAppearance->BorderSize = 3;
			this->HealthBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->HealthBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->HealthBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->HealthBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->HealthBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->HealthBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"HealthBtn.Image")));
			this->HealthBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->HealthBtn->Location = System::Drawing::Point(418, 421);
			this->HealthBtn->Name = L"HealthBtn";
			this->HealthBtn->Padding = System::Windows::Forms::Padding(10, 25, 10, 10);
			this->HealthBtn->Size = System::Drawing::Size(242, 174);
			this->HealthBtn->TabIndex = 16;
			this->HealthBtn->Text = L"Health";
			this->HealthBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->HealthBtn->UseVisualStyleBackColor = false;
			this->HealthBtn->Click += gcnew System::EventHandler(this, &HotelReservation::HealthBtn_Click);
			// 
			// ParkingBtn
			// 
			this->ParkingBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->ParkingBtn->FlatAppearance->BorderSize = 3;
			this->ParkingBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->ParkingBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->ParkingBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->ParkingBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ParkingBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->ParkingBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"ParkingBtn.Image")));
			this->ParkingBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->ParkingBtn->Location = System::Drawing::Point(1202, 421);
			this->ParkingBtn->Name = L"ParkingBtn";
			this->ParkingBtn->Padding = System::Windows::Forms::Padding(10, 15, 10, 10);
			this->ParkingBtn->Size = System::Drawing::Size(242, 174);
			this->ParkingBtn->TabIndex = 15;
			this->ParkingBtn->Text = L"Parking";
			this->ParkingBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->ParkingBtn->UseVisualStyleBackColor = true;
			this->ParkingBtn->Click += gcnew System::EventHandler(this, &HotelReservation::ParkingBtn_Click);
			// 
			// RestaurantBtn
			// 
			this->RestaurantBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->RestaurantBtn->FlatAppearance->BorderSize = 3;
			this->RestaurantBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->RestaurantBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->RestaurantBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->RestaurantBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RestaurantBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->RestaurantBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"RestaurantBtn.Image")));
			this->RestaurantBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->RestaurantBtn->Location = System::Drawing::Point(940, 421);
			this->RestaurantBtn->Name = L"RestaurantBtn";
			this->RestaurantBtn->Padding = System::Windows::Forms::Padding(10);
			this->RestaurantBtn->Size = System::Drawing::Size(242, 174);
			this->RestaurantBtn->TabIndex = 14;
			this->RestaurantBtn->Text = L"Restaurant";
			this->RestaurantBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->RestaurantBtn->UseVisualStyleBackColor = true;
			this->RestaurantBtn->Click += gcnew System::EventHandler(this, &HotelReservation::RestaurantBtn_Click);
			// 
			// FlightBtn
			// 
			this->FlightBtn->BackColor = System::Drawing::Color::White;
			this->FlightBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->FlightBtn->FlatAppearance->BorderSize = 3;
			this->FlightBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->FlightBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->FlightBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->FlightBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->FlightBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->FlightBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"FlightBtn.Image")));
			this->FlightBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->FlightBtn->Location = System::Drawing::Point(678, 421);
			this->FlightBtn->Name = L"FlightBtn";
			this->FlightBtn->Padding = System::Windows::Forms::Padding(10, 20, 10, 10);
			this->FlightBtn->Size = System::Drawing::Size(242, 174);
			this->FlightBtn->TabIndex = 13;
			this->FlightBtn->Text = L"Flight";
			this->FlightBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->FlightBtn->UseVisualStyleBackColor = false;
			this->FlightBtn->Click += gcnew System::EventHandler(this, &HotelReservation::FlightBtn_Click);
			// 
			// KidcornerBtn
			// 
			this->KidcornerBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->KidcornerBtn->FlatAppearance->BorderSize = 3;
			this->KidcornerBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->KidcornerBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->KidcornerBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->KidcornerBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->KidcornerBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->KidcornerBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"KidcornerBtn.Image")));
			this->KidcornerBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->KidcornerBtn->Location = System::Drawing::Point(1202, 612);
			this->KidcornerBtn->Name = L"KidcornerBtn";
			this->KidcornerBtn->Padding = System::Windows::Forms::Padding(10);
			this->KidcornerBtn->Size = System::Drawing::Size(242, 174);
			this->KidcornerBtn->TabIndex = 12;
			this->KidcornerBtn->Text = L"Kid\'s Corner";
			this->KidcornerBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->KidcornerBtn->UseVisualStyleBackColor = true;
			this->KidcornerBtn->Click += gcnew System::EventHandler(this, &HotelReservation::KidcornerBtn_Click);
			// 
			// EntertainmentBtn
			// 
			this->EntertainmentBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->EntertainmentBtn->FlatAppearance->BorderSize = 3;
			this->EntertainmentBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->EntertainmentBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->EntertainmentBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->EntertainmentBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->EntertainmentBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->EntertainmentBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"EntertainmentBtn.Image")));
			this->EntertainmentBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->EntertainmentBtn->Location = System::Drawing::Point(940, 612);
			this->EntertainmentBtn->Name = L"EntertainmentBtn";
			this->EntertainmentBtn->Padding = System::Windows::Forms::Padding(10);
			this->EntertainmentBtn->Size = System::Drawing::Size(242, 174);
			this->EntertainmentBtn->TabIndex = 11;
			this->EntertainmentBtn->Text = L"Entertainment";
			this->EntertainmentBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->EntertainmentBtn->UseVisualStyleBackColor = true;
			this->EntertainmentBtn->Click += gcnew System::EventHandler(this, &HotelReservation::EntertainmentBtn_Click);
			// 
			// SportBtn
			// 
			this->SportBtn->BackColor = System::Drawing::Color::White;
			this->SportBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->SportBtn->FlatAppearance->BorderSize = 3;
			this->SportBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->SportBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->SportBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->SportBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SportBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->SportBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"SportBtn.Image")));
			this->SportBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->SportBtn->Location = System::Drawing::Point(678, 612);
			this->SportBtn->Name = L"SportBtn";
			this->SportBtn->Padding = System::Windows::Forms::Padding(10);
			this->SportBtn->Size = System::Drawing::Size(242, 174);
			this->SportBtn->TabIndex = 17;
			this->SportBtn->Text = L"Sport";
			this->SportBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->SportBtn->UseVisualStyleBackColor = false;
			this->SportBtn->Click += gcnew System::EventHandler(this, &HotelReservation::SportBtn_Click);
			// 
			// PoolBtn
			// 
			this->PoolBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->PoolBtn->FlatAppearance->BorderSize = 3;
			this->PoolBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->PoolBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->PoolBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->PoolBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->PoolBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->PoolBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"PoolBtn.Image")));
			this->PoolBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->PoolBtn->Location = System::Drawing::Point(1202, 234);
			this->PoolBtn->Name = L"PoolBtn";
			this->PoolBtn->Padding = System::Windows::Forms::Padding(10, 15, 10, 10);
			this->PoolBtn->Size = System::Drawing::Size(242, 174);
			this->PoolBtn->TabIndex = 10;
			this->PoolBtn->Text = L"Pool";
			this->PoolBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->PoolBtn->UseVisualStyleBackColor = true;
			this->PoolBtn->Click += gcnew System::EventHandler(this, &HotelReservation::PoolBtn_Click);
			// 
			// ToursBtn
			// 
			this->ToursBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->ToursBtn->FlatAppearance->BorderSize = 3;
			this->ToursBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->ToursBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->ToursBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->ToursBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ToursBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->ToursBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"ToursBtn.Image")));
			this->ToursBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->ToursBtn->Location = System::Drawing::Point(940, 234);
			this->ToursBtn->Name = L"ToursBtn";
			this->ToursBtn->Padding = System::Windows::Forms::Padding(10, 30, 10, 10);
			this->ToursBtn->Size = System::Drawing::Size(242, 174);
			this->ToursBtn->TabIndex = 8;
			this->ToursBtn->Text = L"Tours";
			this->ToursBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->ToursBtn->UseVisualStyleBackColor = true;
			this->ToursBtn->Click += gcnew System::EventHandler(this, &HotelReservation::ToursBtn_Click);
			// 
			// CleaningBtn
			// 
			this->CleaningBtn->BackColor = System::Drawing::Color::White;
			this->CleaningBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->CleaningBtn->FlatAppearance->BorderSize = 3;
			this->CleaningBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->CleaningBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->CleaningBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CleaningBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->CleaningBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->CleaningBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"CleaningBtn.Image")));
			this->CleaningBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->CleaningBtn->Location = System::Drawing::Point(678, 234);
			this->CleaningBtn->Name = L"CleaningBtn";
			this->CleaningBtn->Padding = System::Windows::Forms::Padding(10, 20, 10, 10);
			this->CleaningBtn->Size = System::Drawing::Size(242, 174);
			this->CleaningBtn->TabIndex = 7;
			this->CleaningBtn->Text = L"Cleaning";
			this->CleaningBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->CleaningBtn->UseVisualStyleBackColor = false;
			this->CleaningBtn->Click += gcnew System::EventHandler(this, &HotelReservation::CleaningBtn_Click);
			// 
			// LoungeBtn
			// 
			this->LoungeBtn->BackColor = System::Drawing::Color::White;
			this->LoungeBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->LoungeBtn->FlatAppearance->BorderSize = 3;
			this->LoungeBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->LoungeBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->LoungeBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->LoungeBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->LoungeBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->LoungeBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"LoungeBtn.Image")));
			this->LoungeBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->LoungeBtn->Location = System::Drawing::Point(418, 234);
			this->LoungeBtn->Name = L"LoungeBtn";
			this->LoungeBtn->Padding = System::Windows::Forms::Padding(10, 30, 10, 10);
			this->LoungeBtn->Size = System::Drawing::Size(242, 174);
			this->LoungeBtn->TabIndex = 6;
			this->LoungeBtn->Text = L"Lounge";
			this->LoungeBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->LoungeBtn->UseVisualStyleBackColor = false;
			this->LoungeBtn->Click += gcnew System::EventHandler(this, &HotelReservation::LoungeBtn_Click);
			// 
			// TransportBtn
			// 
			this->TransportBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->TransportBtn->FlatAppearance->BorderSize = 3;
			this->TransportBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->TransportBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->TransportBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->TransportBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->TransportBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->TransportBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"TransportBtn.Image")));
			this->TransportBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->TransportBtn->Location = System::Drawing::Point(1202, 48);
			this->TransportBtn->Name = L"TransportBtn";
			this->TransportBtn->Padding = System::Windows::Forms::Padding(10, 45, 10, 10);
			this->TransportBtn->Size = System::Drawing::Size(242, 174);
			this->TransportBtn->TabIndex = 5;
			this->TransportBtn->Text = L"Transport";
			this->TransportBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->TransportBtn->UseVisualStyleBackColor = true;
			this->TransportBtn->Click += gcnew System::EventHandler(this, &HotelReservation::TransportBtn_Click);
			// 
			// RoomServiceBtn
			// 
			this->RoomServiceBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->RoomServiceBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->RoomServiceBtn->FlatAppearance->BorderSize = 3;
			this->RoomServiceBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->RoomServiceBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->RoomServiceBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->RoomServiceBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RoomServiceBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->RoomServiceBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"RoomServiceBtn.Image")));
			this->RoomServiceBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->RoomServiceBtn->Location = System::Drawing::Point(940, 48);
			this->RoomServiceBtn->Name = L"RoomServiceBtn";
			this->RoomServiceBtn->Padding = System::Windows::Forms::Padding(10, 20, 10, 10);
			this->RoomServiceBtn->Size = System::Drawing::Size(242, 174);
			this->RoomServiceBtn->TabIndex = 4;
			this->RoomServiceBtn->Text = L"Room Service";
			this->RoomServiceBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->RoomServiceBtn->UseVisualStyleBackColor = true;
			this->RoomServiceBtn->Click += gcnew System::EventHandler(this, &HotelReservation::RoomServiceBtn_Click);
			// 
			// SpaBtn
			// 
			this->SpaBtn->BackColor = System::Drawing::Color::White;
			this->SpaBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->SpaBtn->FlatAppearance->BorderSize = 3;
			this->SpaBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->SpaBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->SpaBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->SpaBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SpaBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->SpaBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"SpaBtn.Image")));
			this->SpaBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->SpaBtn->Location = System::Drawing::Point(678, 48);
			this->SpaBtn->Name = L"SpaBtn";
			this->SpaBtn->Padding = System::Windows::Forms::Padding(10, 20, 10, 10);
			this->SpaBtn->Size = System::Drawing::Size(242, 174);
			this->SpaBtn->TabIndex = 3;
			this->SpaBtn->Text = L"Spa";
			this->SpaBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->SpaBtn->UseVisualStyleBackColor = false;
			this->SpaBtn->Click += gcnew System::EventHandler(this, &HotelReservation::SpaBtn_Click);
			// 
			// RoomBtn
			// 
			this->RoomBtn->BackColor = System::Drawing::Color::White;
			this->RoomBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->RoomBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->RoomBtn->FlatAppearance->BorderSize = 3;
			this->RoomBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->RoomBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(218)),
				static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(253)));
			this->RoomBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->RoomBtn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RoomBtn->ForeColor = System::Drawing::Color::DarkSlateBlue;
			this->RoomBtn->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"RoomBtn.Image")));
			this->RoomBtn->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->RoomBtn->Location = System::Drawing::Point(418, 48);
			this->RoomBtn->Name = L"RoomBtn";
			this->RoomBtn->Padding = System::Windows::Forms::Padding(10, 30, 10, 10);
			this->RoomBtn->Size = System::Drawing::Size(242, 174);
			this->RoomBtn->TabIndex = 9;
			this->RoomBtn->Text = L"Room";
			this->RoomBtn->TextAlign = System::Drawing::ContentAlignment::BottomCenter;
			this->RoomBtn->UseVisualStyleBackColor = false;
			this->RoomBtn->Click += gcnew System::EventHandler(this, &HotelReservation::RoomBtn_Click);
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::White;
			this->panel1->Controls->Add(this->panel6);
			this->panel1->Controls->Add(this->panel5);
			this->panel1->Controls->Add(this->panel4);
			this->panel1->Controls->Add(this->panel7);
			this->panel1->Controls->Add(this->panel3);
			this->panel1->Controls->Add(this->panel2);
			this->panel1->Controls->Add(this->ClientIDLabel);
			this->panel1->Controls->Add(this->UpdateBtn);
			this->panel1->Controls->Add(this->DeleteClient);
			this->panel1->Controls->Add(this->SearchClient);
			this->panel1->Controls->Add(this->AddClientBtn);
			this->panel1->Controls->Add(this->pictureBox1);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Controls->Add(this->label4);
			this->panel1->Controls->Add(this->ID1);
			this->panel1->Controls->Add(this->label5);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->Persons);
			this->panel1->Controls->Add(this->ID);
			this->panel1->Controls->Add(this->Mobile);
			this->panel1->Controls->Add(this->Email);
			this->panel1->Controls->Add(this->LastName);
			this->panel1->Controls->Add(this->FirstName);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Left;
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(373, 819);
			this->panel1->TabIndex = 2;
			// 
			// panel6
			// 
			this->panel6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel6->Location = System::Drawing::Point(34, 619);
			this->panel6->Name = L"panel6";
			this->panel6->Size = System::Drawing::Size(135, 5);
			this->panel6->TabIndex = 8;
			// 
			// panel5
			// 
			this->panel5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel5->Location = System::Drawing::Point(194, 471);
			this->panel5->Name = L"panel5";
			this->panel5->Size = System::Drawing::Size(135, 5);
			this->panel5->TabIndex = 8;
			// 
			// panel4
			// 
			this->panel4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel4->Location = System::Drawing::Point(34, 471);
			this->panel4->Name = L"panel4";
			this->panel4->Size = System::Drawing::Size(135, 5);
			this->panel4->TabIndex = 8;
			// 
			// panel7
			// 
			this->panel7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel7->Location = System::Drawing::Point(34, 542);
			this->panel7->Name = L"panel7";
			this->panel7->Size = System::Drawing::Size(295, 5);
			this->panel7->TabIndex = 8;
			// 
			// panel3
			// 
			this->panel3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel3->Location = System::Drawing::Point(34, 394);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(295, 5);
			this->panel3->TabIndex = 8;
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel2->Location = System::Drawing::Point(34, 324);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(295, 5);
			this->panel2->TabIndex = 8;
			// 
			// ClientIDLabel
			// 
			this->ClientIDLabel->AutoSize = true;
			this->ClientIDLabel->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ClientIDLabel->Location = System::Drawing::Point(198, 600);
			this->ClientIDLabel->Name = L"ClientIDLabel";
			this->ClientIDLabel->Size = System::Drawing::Size(84, 24);
			this->ClientIDLabel->TabIndex = 4;
			this->ClientIDLabel->Text = L"Client ID:";
			// 
			// UpdateBtn
			// 
			this->UpdateBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->UpdateBtn->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->UpdateBtn->Location = System::Drawing::Point(23, 770);
			this->UpdateBtn->Name = L"UpdateBtn";
			this->UpdateBtn->Size = System::Drawing::Size(97, 37);
			this->UpdateBtn->TabIndex = 3;
			this->UpdateBtn->Text = L"Update";
			this->UpdateBtn->UseVisualStyleBackColor = true;
			this->UpdateBtn->Click += gcnew System::EventHandler(this, &HotelReservation::UpdateBtn_Click);
			// 
			// DeleteClient
			// 
			this->DeleteClient->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->DeleteClient->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->DeleteClient->Location = System::Drawing::Point(252, 770);
			this->DeleteClient->Name = L"DeleteClient";
			this->DeleteClient->Size = System::Drawing::Size(97, 37);
			this->DeleteClient->TabIndex = 3;
			this->DeleteClient->Text = L"Delete client";
			this->DeleteClient->UseVisualStyleBackColor = true;
			this->DeleteClient->Click += gcnew System::EventHandler(this, &HotelReservation::DeleteClient_Click);
			// 
			// SearchClient
			// 
			this->SearchClient->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->SearchClient->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SearchClient->Location = System::Drawing::Point(140, 770);
			this->SearchClient->Name = L"SearchClient";
			this->SearchClient->Size = System::Drawing::Size(97, 37);
			this->SearchClient->TabIndex = 3;
			this->SearchClient->Text = L"Search ID";
			this->SearchClient->UseVisualStyleBackColor = true;
			this->SearchClient->Click += gcnew System::EventHandler(this, &HotelReservation::SearchClient_Click);
			// 
			// AddClientBtn
			// 
			this->AddClientBtn->BackColor = System::Drawing::Color::White;
			this->AddClientBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(99)),
				static_cast<System::Int32>(static_cast<System::Byte>(94)), static_cast<System::Int32>(static_cast<System::Byte>(86)));
			this->AddClientBtn->FlatAppearance->BorderSize = 2;
			this->AddClientBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->AddClientBtn->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->AddClientBtn->Location = System::Drawing::Point(232, 667);
			this->AddClientBtn->Name = L"AddClientBtn";
			this->AddClientBtn->Size = System::Drawing::Size(117, 43);
			this->AddClientBtn->TabIndex = 3;
			this->AddClientBtn->Text = L"Add client";
			this->AddClientBtn->UseVisualStyleBackColor = false;
			this->AddClientBtn->Click += gcnew System::EventHandler(this, &HotelReservation::AddClientBtn_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(54, 62);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(265, 135);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 2;
			this->pictureBox1->TabStop = false;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(37, 344);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(97, 25);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Last name";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(197, 421);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(78, 25);
			this->label4->TabIndex = 1;
			this->label4->Text = L"Persons";
			// 
			// ID1
			// 
			this->ID1->AutoSize = true;
			this->ID1->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ID1->Location = System::Drawing::Point(37, 569);
			this->ID1->Name = L"ID1";
			this->ID1->Size = System::Drawing::Size(30, 25);
			this->ID1->TabIndex = 1;
			this->ID1->Text = L"ID";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(37, 492);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(58, 25);
			this->label5->TabIndex = 1;
			this->label5->Text = L"Email";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(37, 421);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(71, 25);
			this->label3->TabIndex = 1;
			this->label3->Text = L"Mobile";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(37, 270);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(99, 25);
			this->label1->TabIndex = 1;
			this->label1->Text = L"First name";
			// 
			// Persons
			// 
			this->Persons->BackColor = System::Drawing::Color::White;
			this->Persons->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->Persons->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Persons->Location = System::Drawing::Point(194, 448);
			this->Persons->Name = L"Persons";
			this->Persons->Size = System::Drawing::Size(135, 21);
			this->Persons->TabIndex = 0;
			// 
			// ID
			// 
			this->ID->BackColor = System::Drawing::Color::White;
			this->ID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ID->Location = System::Drawing::Point(34, 596);
			this->ID->Name = L"ID";
			this->ID->Size = System::Drawing::Size(135, 21);
			this->ID->TabIndex = 0;
			// 
			// Mobile
			// 
			this->Mobile->BackColor = System::Drawing::Color::White;
			this->Mobile->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->Mobile->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Mobile->Location = System::Drawing::Point(34, 448);
			this->Mobile->Name = L"Mobile";
			this->Mobile->Size = System::Drawing::Size(135, 21);
			this->Mobile->TabIndex = 0;
			// 
			// Email
			// 
			this->Email->BackColor = System::Drawing::Color::White;
			this->Email->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->Email->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Email->Location = System::Drawing::Point(34, 519);
			this->Email->Name = L"Email";
			this->Email->Size = System::Drawing::Size(295, 21);
			this->Email->TabIndex = 0;
			// 
			// LastName
			// 
			this->LastName->BackColor = System::Drawing::Color::White;
			this->LastName->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->LastName->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->LastName->Location = System::Drawing::Point(34, 371);
			this->LastName->Name = L"LastName";
			this->LastName->Size = System::Drawing::Size(295, 21);
			this->LastName->TabIndex = 0;
			// 
			// FirstName
			// 
			this->FirstName->BackColor = System::Drawing::Color::White;
			this->FirstName->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->FirstName->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->FirstName->Location = System::Drawing::Point(34, 298);
			this->FirstName->Name = L"FirstName";
			this->FirstName->Size = System::Drawing::Size(295, 24);
			this->FirstName->TabIndex = 0;
			// 
			// CloseBtn
			// 
			this->CloseBtn->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)),
				static_cast<System::Int32>(static_cast<System::Byte>(188)), static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->CloseBtn->FlatAppearance->BorderSize = 0;
			this->CloseBtn->FlatAppearance->MouseDownBackColor = System::Drawing::Color::White;
			this->CloseBtn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::White;
			this->CloseBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CloseBtn->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->CloseBtn->Location = System::Drawing::Point(1445, 12);
			this->CloseBtn->Name = L"CloseBtn";
			this->CloseBtn->Size = System::Drawing::Size(34, 32);
			this->CloseBtn->TabIndex = 19;
			this->CloseBtn->Text = L"X";
			this->CloseBtn->UseVisualStyleBackColor = true;
			this->CloseBtn->Click += gcnew System::EventHandler(this, &HotelReservation::CloseBtn_Click);
			// 
			// panel8
			// 
			this->panel8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(99)), static_cast<System::Int32>(static_cast<System::Byte>(94)),
				static_cast<System::Int32>(static_cast<System::Byte>(86)));
			this->panel8->Location = System::Drawing::Point(379, 80);
			this->panel8->Name = L"panel8";
			this->panel8->Size = System::Drawing::Size(3, 675);
			this->panel8->TabIndex = 20;
			// 
			// HotelReservation
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1491, 819);
			this->Controls->Add(this->panel8);
			this->Controls->Add(this->CloseBtn);
			this->Controls->Add(this->ActivitiesBtn);
			this->Controls->Add(this->HealthBtn);
			this->Controls->Add(this->ParkingBtn);
			this->Controls->Add(this->RestaurantBtn);
			this->Controls->Add(this->FlightBtn);
			this->Controls->Add(this->KidcornerBtn);
			this->Controls->Add(this->EntertainmentBtn);
			this->Controls->Add(this->SportBtn);
			this->Controls->Add(this->PoolBtn);
			this->Controls->Add(this->ToursBtn);
			this->Controls->Add(this->CleaningBtn);
			this->Controls->Add(this->LoungeBtn);
			this->Controls->Add(this->TransportBtn);
			this->Controls->Add(this->RoomServiceBtn);
			this->Controls->Add(this->SpaBtn);
			this->Controls->Add(this->RoomBtn);
			this->Controls->Add(this->panel1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"HotelReservation";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"HotelReservation";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);

		}
		#pragma endregion
		private: System::Void RoomBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Room^ room = gcnew Room();
			room->ShowDialog();
		}
		private: System::Void SpaBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Spa^ spa = gcnew Spa();
			spa->ShowDialog();
		}
		private: System::Void TransportBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Transport^ transport = gcnew Transport();
			transport->ShowDialog();
		}
		private: System::Void LoungeBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Lounge^ lounge = gcnew Lounge();
			lounge->ShowDialog();
		}
		private: System::Void CleaningBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Cleaning^ cleaning = gcnew Cleaning();
			cleaning->ShowDialog();
		}
		private: System::Void PoolBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Pool^ pool = gcnew Pool();
			pool->ShowDialog();
		}
		private: System::Void FlightBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Flight^ flight = gcnew Flight();
			flight->ShowDialog();
		}
		private: System::Void ParkingBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Parking^ parking = gcnew Parking();
			parking->ShowDialog();
		}
		private: System::Void ActivitiesBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Activities^ activities = gcnew Activities();
			activities->ShowDialog();
		}
		private: System::Void EntertainmentBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Entertainment^ entertainment = gcnew Entertainment();
			entertainment->ShowDialog();
		}
		private: System::Void KidcornerBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			KidsCorner^ kidsCorner = gcnew KidsCorner();
			kidsCorner->ShowDialog();
		}
		private: System::Void HealthBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Health^ health = gcnew Health();
			health->ShowDialog();
		}
		private: System::Void SportBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Sport^ sport= gcnew Sport();
			sport->ShowDialog();
		}
		private: System::Void RoomServiceBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			RoomService^ roomService = gcnew RoomService();
			roomService->ShowDialog();
		}
		private: System::Void RestaurantBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Restaurant^ restaurant = gcnew Restaurant();
			restaurant->ShowDialog();
		}
		private: System::Void ToursBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			Tours^ tours = gcnew Tours();
			tours->ShowDialog();
		}


		private: System::Void AddClientBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			try
			{
				String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
				MySqlConnection^ con = gcnew MySqlConnection(constr);

				String^ firstName = FirstName->Text;
				String^ lastName = LastName->Text;
				int mobile = Int32::Parse(Mobile->Text);
				int persons = Int32::Parse(Persons->Text);
				String^ email = Email->Text;

				MySqlCommand^ cmd = gcnew MySqlCommand ("INSERT INTO client_info (first_name, last_name, mobile_num, num_of_persons, email) VALUES ('" + firstName + "', '" + lastName + "', " + mobile + ", " + persons + ", '" + email + "')", con);
				MySqlDataReader^ dr;
				con->Open();
				dr = cmd->ExecuteReader();
				MessageBox::Show("User info save");
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}


		private: System::Void SearchClient_Click(System::Object^ sender, System::EventArgs^ e) {
			try
			{
				String^ email = Email->Text;
				String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
				MySqlConnection^ con = gcnew MySqlConnection(constr);
				MySqlCommand^ cmd = gcnew MySqlCommand("select client_id from client_info WHERE email='" + email + "' ", con);

				con->Open();
				MySqlDataReader^ dr = cmd->ExecuteReader();

				while (dr->Read())
				{
					ClientIDLabel->Text = "Client ID: " + dr->GetString(0);
				}
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}

		private: System::Void DeleteClient_Click(System::Object^ sender, System::EventArgs^ e) {
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			String^ email = Email->Text;
			MySqlCommand^ cmd = gcnew MySqlCommand("delete from client_info where email='" + email + "' ", con);

			con->Open();
			MySqlDataReader^ dr = cmd->ExecuteReader();
			MessageBox::Show("Deleted");
			con->Close();
		}

		private: System::Void UpdateBtn_Click(System::Object^ sender, System::EventArgs^ e) {
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);
			
			String^ firstName = FirstName->Text;
			String^ lastName = LastName->Text;
			int mobile = Int32::Parse(Mobile->Text);
			int persons = Int32::Parse(Persons->Text);
			String^ email = Email->Text;
			int id = Int32::Parse(ID->Text);

			MySqlCommand^ cmd = gcnew MySqlCommand("update client_info set first_name='" + firstName + "', last_name='" + lastName + "', mobile_num=" + mobile + ", num_of_persons=" + persons + ", email='" + email + "' where client_id=" + id + "", con);

			con->Open();
			MySqlDataReader^ dr = cmd->ExecuteReader();
			MessageBox::Show("Updated");
			con->Close();
		}

	private: System::Void CloseBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		HotelReservation::Close();
	}
};
}