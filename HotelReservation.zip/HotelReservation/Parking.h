#pragma once

namespace HotelReservation {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for Parking
	/// </summary>
	public ref class Parking : public System::Windows::Forms::Form
	{
	public:
		Parking(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Parking()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^ Security;
	private: System::Windows::Forms::CheckBox^ RoofTop;
	private: System::Windows::Forms::CheckBox^ Reserved;
	protected:

	protected:


	private: System::Windows::Forms::Button^ Ok;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ ClientID;
	private: System::Windows::Forms::Button^ Delete;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Panel^ panel1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Parking::typeid));
			this->Security = (gcnew System::Windows::Forms::CheckBox());
			this->RoofTop = (gcnew System::Windows::Forms::CheckBox());
			this->Reserved = (gcnew System::Windows::Forms::CheckBox());
			this->Ok = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->ClientID = (gcnew System::Windows::Forms::TextBox());
			this->Delete = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// Security
			// 
			this->Security->AutoSize = true;
			this->Security->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Security->Location = System::Drawing::Point(61, 95);
			this->Security->Name = L"Security";
			this->Security->Size = System::Drawing::Size(123, 24);
			this->Security->TabIndex = 1;
			this->Security->Text = L"With security";
			this->Security->UseVisualStyleBackColor = true;
			// 
			// RoofTop
			// 
			this->RoofTop->AutoSize = true;
			this->RoofTop->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RoofTop->Location = System::Drawing::Point(61, 146);
			this->RoofTop->Name = L"RoofTop";
			this->RoofTop->Size = System::Drawing::Size(94, 24);
			this->RoofTop->TabIndex = 1;
			this->RoofTop->Text = L"Roof top";
			this->RoofTop->UseVisualStyleBackColor = true;
			// 
			// Reserved
			// 
			this->Reserved->AutoSize = true;
			this->Reserved->Font = (gcnew System::Drawing::Font(L"Futura Bk BT", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Reserved->Location = System::Drawing::Point(61, 197);
			this->Reserved->Name = L"Reserved";
			this->Reserved->Size = System::Drawing::Size(98, 24);
			this->Reserved->TabIndex = 1;
			this->Reserved->Text = L"Reserved";
			this->Reserved->UseVisualStyleBackColor = true;
			// 
			// Ok
			// 
			this->Ok->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Ok->Location = System::Drawing::Point(310, 666);
			this->Ok->Name = L"Ok";
			this->Ok->Size = System::Drawing::Size(75, 29);
			this->Ok->TabIndex = 3;
			this->Ok->Text = L"Ok";
			this->Ok->UseVisualStyleBackColor = true;
			this->Ok->Click += gcnew System::EventHandler(this, &Parking::Ok_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(193, 649);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(66, 16);
			this->label1->TabIndex = 12;
			this->label1->Text = L"Client ID";
			// 
			// ClientID
			// 
			this->ClientID->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->ClientID->Location = System::Drawing::Point(190, 669);
			this->ClientID->Name = L"ClientID";
			this->ClientID->Size = System::Drawing::Size(100, 15);
			this->ClientID->TabIndex = 11;
			// 
			// Delete
			// 
			this->Delete->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Delete->Location = System::Drawing::Point(401, 667);
			this->Delete->Name = L"Delete";
			this->Delete->Size = System::Drawing::Size(75, 28);
			this->Delete->TabIndex = 13;
			this->Delete->Text = L"Delete";
			this->Delete->UseVisualStyleBackColor = true;
			this->Delete->Click += gcnew System::EventHandler(this, &Parking::Delete_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Futura Hv BT", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(41, 49);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(126, 22);
			this->label2->TabIndex = 12;
			this->label2->Text = L"Parking type";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->pictureBox1->Location = System::Drawing::Point(524, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(440, 740);
			this->pictureBox1->TabIndex = 14;
			this->pictureBox1->TabStop = false;
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(80)), static_cast<System::Int32>(static_cast<System::Byte>(188)),
				static_cast<System::Int32>(static_cast<System::Byte>(222)));
			this->panel1->Location = System::Drawing::Point(191, 688);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(99, 3);
			this->panel1->TabIndex = 15;
			// 
			// Parking
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(964, 740);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->Delete);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->ClientID);
			this->Controls->Add(this->Ok);
			this->Controls->Add(this->Reserved);
			this->Controls->Add(this->RoofTop);
			this->Controls->Add(this->Security);
			this->Name = L"Parking";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Parking";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		private: System::Void Ok_Click(System::Object^ sender, System::EventArgs^ e) {
			String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
			MySqlConnection^ con = gcnew MySqlConnection(constr);

			int clientid = Int32::Parse(ClientID->Text);

			if (Security->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO parking_info (client_id, service) VALUES (" + clientid + ", 'With Security')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (RoofTop->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO parking_info (client_id, service) VALUES (" + clientid + ", 'Roof Top')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			if (Reserved->Checked)
			{
				try
				{
					MySqlCommand^ cmd = gcnew MySqlCommand("INSERT INTO parking_info (client_id, service) VALUES (" + clientid + ", 'Reserved')", con);
					MySqlDataReader^ dr;
					con->Open();
					dr = cmd->ExecuteReader();
					con->Close();
				}
				catch (Exception^ ex)
				{
					MessageBox::Show(ex->Message);
				}
			}

			Parking::Close();
		}


		private: System::Void Delete_Click(System::Object^ sender, System::EventArgs^ e) {
			try
			{
				String^ constr = "Server=127.0.0.1;Uid=root;Pwd=;Database=hotel_reservation";
				MySqlConnection^ con = gcnew MySqlConnection(constr);

				int clientid = Int32::Parse(ClientID->Text);
				MySqlCommand^ cmd = gcnew MySqlCommand("delete from parking_info where client_id=" + clientid + " ", con);

				con->Open();
				MySqlDataReader^ dr = cmd->ExecuteReader();
				MessageBox::Show("Deleted");
				con->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show(ex->Message);
			}
		}
};
}
